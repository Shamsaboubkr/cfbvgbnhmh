// Proves the spec's save/push cadence against the real AudioPlayerService:
//   * local SQLite every 10 s while playing
//   * Drive every 30 s while playing
//   * immediate push on pause / book switch / app close
//   * nothing at all while playback is stopped
//
// The intervals are injected (40 ms / 100 ms here) instead of waiting 30 real
// seconds, but the code path exercised is the production one.
import 'dart:io';

import 'package:bookspeaker/auth/google_sign_in_service.dart';
import 'package:bookspeaker/library/book_model.dart';
import 'package:bookspeaker/player/audio_player_service.dart';
import 'package:bookspeaker/progress/drive_sync_service.dart';
import 'package:bookspeaker/progress/local_storage_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:just_audio/just_audio.dart';

/// A real [AudioPlayer] with the platform surface silenced. The cadence under
/// test is pure Dart, so this keeps the test honest (the production
/// AudioPlayerService, the production code paths) without an audio plugin.
class StubAudioPlayer extends AudioPlayer {
  @override
  Future<Duration?> setFilePath(
    String filePath, {
    Duration? initialPosition,
    bool preload = true,
    dynamic tag,
  }) async =>
      const Duration(hours: 3);

  @override
  Future<void> play() async {}

  @override
  Future<void> pause() async {}

  @override
  Future<void> stop() async {}

  @override
  Future<void> seek(final Duration? position, {int? index}) async {}

  @override
  Future<void> setSpeed(final double speed) async {}

  @override
  Future<void> setVolume(final double volume) async {}

  @override
  Future<void> setSkipSilenceEnabled(bool enabled) async {}
}

/// Stands in for Drive: records every push instead of touching the network.
class RecordingSyncService extends DriveSyncService {
  RecordingSyncService(super.local, super.auth);

  final List<Book> pushes = [];

  @override
  Future<void> pushBook(Book book) async {
    pushes.add(book);
  }
}

Book _book(String id) => Book(
      bookId: id,
      title: 'Book $id',
      author: 'Author $id',
      filePath: '/tmp/bookspeaker-test/$id.mp3',
      folderName: 'test',
      format: AudioFormat.mp3,
      totalDuration: const Duration(hours: 3),
      dateAdded: DateTime.now(),
      isAvailable: true,
    );

void main() {
  // just_audio registers a method-call handler when an AudioPlayer is built,
  // which needs the (test) binding up.
  TestWidgetsFlutterBinding.ensureInitialized();

  late Directory tmp;
  late LocalStorageService local;
  late RecordingSyncService sync;
  late AudioPlayerService player;

  setUp(() {
    tmp = Directory.systemTemp.createTempSync('bookspeaker_cadence');
    local = LocalStorageService.forTesting(tmp.path);
    sync = RecordingSyncService(local, GoogleSignInService());
    player = AudioPlayerService(
      local,
      sync,
      audioPlayer: StubAudioPlayer(),
      localSaveInterval: const Duration(milliseconds: 60),
      drivePushInterval: const Duration(milliseconds: 200),
    );
  });

  tearDown(() {
    player.dispose();
    local.db.close();
    if (tmp.existsSync()) tmp.deleteSync(recursive: true);
  });

  Future<void> startBook(String id) async {
    await player.openBook(_book(id), autoplay: false);
    await player.play();
  }

  test('playing starts a repeating Drive push cadence (30 s in production)',
      () async {
    expect(player.cadenceRunning, isFalse, reason: 'idle before playback');

    await startBook('a1');
    expect(player.cadenceRunning, isTrue, reason: 'play() starts the timers');

    // 200 ms interval over 1 s. The claim under test is "the timer keeps
    // firing" (>= 2), not an exact count: a stalled CI VM must not fail this.
    await Future<void>.delayed(const Duration(milliseconds: 1000));

    expect(sync.pushes.length, greaterThanOrEqualTo(2));
    expect(sync.pushes.every((b) => b.bookId == 'a1'), isTrue);
  });

  test('playing also saves locally on its own faster cadence (10 s)',
      () async {
    await startBook('a2');
    // 60 ms interval over 900 ms; allow for a slow VM.
    await Future<void>.delayed(const Duration(milliseconds: 900));

    expect(player.localSaveTick, greaterThanOrEqualTo(3));
    expect(player.lastLocalSaveAt, isNotNull);
    // The row really exists in SQLite after the cadence ran.
    expect(local.db.progressFor('a2'), isNotNull);
  });

  test('pause stops the cadence and pushes once, immediately', () async {
    await startBook('a3');
    await Future<void>.delayed(const Duration(milliseconds: 500));
    final before = sync.pushes.length;
    expect(before, greaterThan(0));

    await player.pause();
    // The push happens synchronously on the pause call — no waiting.
    expect(sync.pushes.length, before + 1);
    expect(player.cadenceRunning, isFalse);

    await Future<void>.delayed(const Duration(milliseconds: 300));
    expect(sync.pushes.length, before + 1,
        reason: 'no periodic pushes once paused');
  });

  test('switching books pushes the book being left', () async {
    await player.openBook(_book('old'), autoplay: false);
    expect(sync.pushes, isEmpty);

    await player.openBook(_book('new'), autoplay: false);
    expect(sync.pushes.map((b) => b.bookId), ['old']);
  });

  test('app close saves and pushes (not local-only)', () async {
    await startBook('a4');
    await Future<void>.delayed(const Duration(milliseconds: 120));
    final before = sync.pushes.length;

    await player.saveAndPush(awaitPush: true);

    expect(sync.pushes.length, before + 1);
    expect(sync.pushes.last.bookId, 'a4');
    expect(local.db.progressFor('a4'), isNotNull);
  });

  test('does nothing at all when no book is loaded', () async {
    await player.saveAndPush(awaitPush: true);
    await Future<void>.delayed(const Duration(milliseconds: 150));
    expect(sync.pushes, isEmpty);
    expect(player.cadenceRunning, isFalse);
  });
}

# Bookspeaker

**Listen everywhere. Pick up anywhere.**

A local audiobook player for Android + Windows: your audio files never leave your
device, only a few KB of *progress* sync between devices through your own Google
Drive (hidden app-data folder).

* Package ID: `com.bookspeaker.app`
* Version: 1.0.5 (versionCode 6)
* Android support: **Android 9 (API 28) → Android 15 (API 35)**
* Framework: Flutter 3.24.5 / Dart 3.5.4, Java 17, Android Gradle Plugin 8.1, Gradle 8.3

---

## 1. Build the APK

```bash
# one-time environment (already created in this workspace)
source /home/user/.envrc_bs.sh     # JDK 17 + Flutter 3.24.5 + Android SDK 35

cd bookspeaker
flutter pub get
flutter build apk --release --no-tree-shake-icons
```

Output: `build/app/outputs/flutter-apk/app-release.apk` (universal APK:
`armeabi-v7a` + `arm64-v8a` + `x86_64`, so it covers every Android 9–15 device).
The built, signed artifact also lives in `release/Bookspeaker-v1.0.5-android9-15-universal.apk`
(installs straight over v1.0.0–v1.0.4 — same signing key).

A smaller download (≈35 MB instead of 69 MB) for modern 64-bit phones:

```bash
flutter build apk --release --split-per-abi --no-tree-shake-icons
# build/app/outputs/flutter-apk/app-arm64-v8a-release.apk
```

> Split builds use a higher `versionCode` than the universal APK, so choose one variant
> and keep using it — installing the universal build over an arm64 install counts as a
> downgrade. See `BUILD_REPORT.md` for checksums and verification details.

The release build is signed with `android/app/bookspeaker-release.jks`
(alias `bookspeaker`, password `bookspeaker`) configured through
`android/key.properties`. **Regenerate both before any public release.**

```bash
adb install -r build/app/outputs/flutter-apk/app-release.apk
```

## 2. Google Drive sync setup (optional — the app is fully usable offline)

The app ships with Google Sign-In wired up, but a build can only sign in if the
OAuth client exists in *your* Google Cloud project:

1. Create a project in [Google Cloud Console](https://console.cloud.google.com).
2. **APIs & Services → Library →** enable **Google Drive API**.
3. **APIs & Services → OAuth consent screen** → External → add yourself as a test user,
   and add the scope `.../auth/drive.appdata` (non-sensitive, no verification needed).
4. **Credentials → Create credentials → OAuth client ID → Android**, then:
   * Package name: `com.bookspeaker.app`
   * SHA-1 of the signing key:
     * release: `06:8A:6A:70:AE:EF:FC:2A:97:EA:26:3F:15:5E:E0:B6:C3:F6:92:87`
     * (regenerate with `keytool -list -v -keystore android/app/bookspeaker-release.jks -alias bookspeaker`)
5. Rebuild. `[Continue with Google]` now works; without this step the app shows a
   clear message and keeps running in local-only mode.

Drive layout created by the app (inside the hidden `appDataFolder`):

```
Bookspeaker/
├── manifest.json
└── <bookId>_progress.json      (1–3 KB each: position, speed, bookmarks, device history)
```

## 3. What's implemented (V1 checklist)

| Spec feature | Status |
|---|---|
| MP3, M4A, Opus playback (just_audio + audio_service) | ✅ |
| Folder watching (auto library, re-link on move/rename) | ✅ |
| SHA-256 audio fingerprint book identity (1 MB head + 1 MB tail + payload size) | ✅ |
| Cover art: embedded → folder image → OpenLibrary → Google Books → iTunes → placeholder | ✅ |
| Manual cover override + embed into MP3 (ID3v2 APIC, fingerprint-safe rewrite) | ✅ |
| Online lookup sheet with preview, reason when empty, and retry | ✅ |
| Dynamic UI colour from cover art + contrast guard (≥ 4.5) | ✅ |
| Light / Dark / System theme, 400 ms animated transitions | ✅ |
| Per-book speed 0.5x–3x, configurable skip (5–60 s) | ✅ |
| Sleep timer with 20 s fade-out | ✅ |
| Silence skipping — opt-in setting, **off by default** | ✅ |
| Bookmarks with labels (player + dedicated screen) | ✅ |
| Local save every 10 s, Drive push every 30 s, save on pause/close/switch | ✅ |
| Google Sign-In, Drive app-data sync, manifest + per-book progress files | ✅ |
| Device-history conflict picker, auto-resume, Drive-full warning | ✅ |
| Deleted file → greyed out (progress kept), Locate File / Remove | ✅ |
| Android media notification + lock-screen controls | ✅ |
| Offline-first: everything works without internet, pending push on reconnect | ✅ |
| Onboarding (splash → folder picker → scan results), empty states | ✅ |
| Back button backgrounds the app; playback + UI stay alive | ✅ |
| Library: Continue Listening, Recent, Folders, All Books, search, avatar | ✅ |
| Windows desktop support (same codebase, `windows/` scaffold present) | ⏳ not built yet (Android APK first, per request) |

### Performance notes (v1.0.1)

* Playback state lives in `AudioPlayerService`, a separate provider — position ticks
  never rebuild the library.
* Tag reads, fingerprinting, embedded-cover extraction and ID3 embedding run in worker
  isolates; folder walks are async.
* Cover resolution happens at most 6 books per pass and is remembered per book
  (`cover_checked`), so relaunching is fast; Settings → Storage → *Clear Cache* re-arms it.
* Drive pushes are fire-and-forget: opening a book, pausing or switching never waits for
  the network.

### Notes on the fingerprint algorithm

The spec hashes the *total* file size as the third component. Because the app itself
embeds cover art (which grows the container but never touches the audio), that would change
a book's ID — and orphan its progress — every time a cover was set. Bookspeaker hashes the
**audio payload size** (file size minus the metadata header) instead, which keeps the spec's
guarantee "tags edited → same ID" true for the app's own writes. This is covered by tests.

### Cover art behaviour (v1.0.2)

* Every applied cover gets a **new cache file**; the old one is deleted, so replacing artwork
  always takes effect immediately (no stale image-cache entries).
* Online sources are tried in order: OpenLibrary → Google Books → iTunes. **Google Books
  currently rate-limits anonymous callers (HTTP 429)**; the app says so and falls back.
  Verified live: OpenLibrary and iTunes both returned 600px-class artwork.
* Lookup results always surface as UI: a preview sheet (on-demand) or a card in the library
  (automatic). Failures show the reason and a *Try again* button — never a silent no-op.
* Replacing the artwork also **rewrites the MP3's ID3 picture frame**, so the file itself is
  corrected. M4A/Opus files keep the artwork in Bookspeaker only (documented limitation).

### Known limitations (documented, not hidden)

* **Cover embedding is MP3-only.** The ID3v2 APIC rewriter preserves TIT2/TPE1/TALB/…,
  replaces the picture frame and leaves the audio payload byte-identical (so the
  fingerprint never changes). For M4A (`covr`) and Opus (`METADATA_BLOCK_PICTURE`)
  the cover is cached and shown, but not written back into the file yet.
* Google Sign-In requires the OAuth client from step 2 (otherwise local-only mode).
* `MANAGE_EXTERNAL_STORAGE` is requested so a user-chosen audiobook folder can be
  watched on Android 11+; if the user prefers, "Pick audio files instead" works with
  scoped media access only.
* Drift table definitions (`lib/data/tables.dart`) mirror the schema 1:1, but the
  runtime store executes the same DDL directly over `sqlite3` — so `bookspeaker.db`
  is byte-for-byte the specified schema without needing code generation. Swapping to
  Drift DAOs later needs no migration.

## 4. Project layout

```
lib/
├── main.dart                       # service graph + AudioService.init + permissions
├── app/bookspeaker_app.dart        # providers, animated theme, tabs, mini player
├── app/theme/                      # dynamic / light / dark themes
├── app_state.dart                  # AppState: library, playback, covers, settings
├── auth/                           # Google Sign-In + auth state
├── data/                           # sqlite3 store + Drift table definitions
├── library/                        # models, fingerprint, scanner, watcher, screens
├── player/                         # playback service, player screen, sleep timer
├── covers/                         # cover service, palette, sources, ID3 writer
├── progress/                       # local storage + Drive sync
├── bookmarks/bookmarks_screen.dart
├── settings/settings_screen.dart
└── widgets/                        # covers, sync indicator, conflict sheet, empty states
```

## 5. Persistence locations (Android)

```
/data/data/com.bookspeaker.app/files/            (app support dir)
├── bookspeaker.db        # books, progress, bookmarks, device_history, watched_folders, settings
└── cover_cache/<bookId>.jpg
```

## 6. Tests

```bash
flutter test        # 14 tests: models, SQLite layer, fingerprint + ID3 cover embedding
flutter analyze     # 0 errors, 0 warnings
```

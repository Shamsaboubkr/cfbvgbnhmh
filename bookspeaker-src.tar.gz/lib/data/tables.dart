/// Drift (SQLite) table definitions.
///
/// These are the canonical table definitions; they mirror the SQL schema in the
/// build specification one-to-one (same column names, same types, same primary
/// keys). The runtime data layer in `db.dart` executes the identical DDL
/// directly against the bundled `sqlite3` library, so the on-disk file
/// (`bookspeaker.db`) and its schema are exactly what the spec describes and can
/// be handed to Drift code generation later without a migration.
library;

import 'package:drift/drift.dart';

@DataClassName('BookRow')
class Books extends Table {
  TextColumn get bookId => text()();
  TextColumn get title => text()();
  TextColumn get author => text().nullable()();
  TextColumn get filePath => text()();
  TextColumn get folderName => text()();
  TextColumn get format => text()();
  IntColumn get totalDurationMs => integer().nullable()();
  TextColumn get dateAdded => text()();
  IntColumn get isAvailable => integer().withDefault(const Constant(1))();
  TextColumn get coverCachePath => text().nullable()();

  @override
  Set<Column<Object>> get primaryKey => {bookId};
}

@DataClassName('ProgressRow')
class Progress extends Table {
  TextColumn get bookId => text()();
  IntColumn get positionMs => integer().withDefault(const Constant(0))();
  IntColumn get totalDurationMs => integer().nullable()();
  RealColumn get percentComplete => real().withDefault(const Constant(0))();
  RealColumn get playbackSpeed => real().withDefault(const Constant(1.0))();
  IntColumn get finished => integer().withDefault(const Constant(0))();
  TextColumn get lastPlayed => text().nullable()();
  TextColumn get lastDeviceName => text().nullable()();
  TextColumn get lastDeviceType => text().nullable()();
  TextColumn get syncStatus => text().withDefault(const Constant('pending'))();

  @override
  Set<Column<Object>> get primaryKey => {bookId};
}

@DataClassName('BookmarkRow')
class Bookmarks extends Table {
  TextColumn get id => text()();
  TextColumn get bookId => text()();
  IntColumn get positionMs => integer()();
  TextColumn get label => text().nullable()();
  TextColumn get created => text()();

  @override
  Set<Column<Object>> get primaryKey => {id};
}

@DataClassName('DeviceHistoryRow')
class DeviceHistory extends Table {
  TextColumn get id => text()();
  TextColumn get bookId => text()();
  TextColumn get deviceName => text()();
  TextColumn get deviceType => text()();
  IntColumn get positionMs => integer()();
  TextColumn get timestamp => text()();

  @override
  Set<Column<Object>> get primaryKey => {id};
}

@DataClassName('WatchedFolderRow')
class WatchedFolders extends Table {
  TextColumn get id => text()();
  TextColumn get folderPath => text()();
  TextColumn get dateAdded => text()();

  @override
  Set<Column<Object>> get primaryKey => {id};
}

@DataClassName('SettingRow')
class Settings extends Table {
  TextColumn get key => text()();
  TextColumn get value => text()();

  @override
  Set<Column<Object>> get primaryKey => {key};
}

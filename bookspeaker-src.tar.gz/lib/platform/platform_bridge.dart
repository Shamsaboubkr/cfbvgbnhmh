/// Bridge to the native side (Android).
///
/// Currently used for one thing: turning the system Back button at the root of
/// the app into "move the task to the background" instead of finishing the
/// activity — which is what made the screen go white and made reopening slow
/// (Android showed the launch window while the whole app cold-started again).
library;

import 'dart:io';

import 'package:flutter/services.dart';

class PlatformBridge {
  static const MethodChannel _channel =
      MethodChannel('com.bookspeaker.app/platform');

  /// Sends the app to the background, keeping playback (and the whole Flutter
  /// engine) alive so returning to it is instant.
  static Future<bool> moveTaskToBack() async {
    if (!Platform.isAndroid) return false;
    try {
      final moved = await _channel.invokeMethod<bool>('moveTaskToBack');
      return moved ?? false;
    } catch (_) {
      return false;
    }
  }
}

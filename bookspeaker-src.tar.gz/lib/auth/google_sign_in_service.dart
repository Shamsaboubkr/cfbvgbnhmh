/// Google Sign-In with the Drive app-folder scope.
///
/// Progress sync only ever touches `drive.appdata` — a hidden, app-private
/// folder — so the app can never see the rest of the user's Drive.
library;

import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';

class GoogleAuthUser {
  final String email;
  final String displayName;
  final String? photoUrl;
  const GoogleAuthUser({
    required this.email,
    required this.displayName,
    this.photoUrl,
  });
}

class GoogleSignInService extends ChangeNotifier {
  GoogleSignInService();

  static const driveAppDataScope =
      'https://www.googleapis.com/auth/drive.appdata';

  final GoogleSignIn _googleSignIn = GoogleSignIn(
    scopes: const [driveAppDataScope],
  );

  GoogleSignInAccount? _account;
  GoogleAuthUser? _user;
  String? _accessToken;
  DateTime? _tokenExpiry;
  bool _busy = false;
  String? _lastError;

  GoogleAuthUser? get user => _user;
  bool get isSignedIn => _account != null && _user != null;
  bool get busy => _busy;
  String? get lastError => _lastError;
  String? get accessToken => _accessToken;

  void _setBusy(bool value) {
    _busy = value;
    notifyListeners();
  }

  Future<void> _adopt(GoogleSignInAccount? account) async {
    _account = account;
    if (account == null) {
      _user = null;
      _accessToken = null;
      _tokenExpiry = null;
      notifyListeners();
      return;
    }
    _user = GoogleAuthUser(
      email: account.email,
      displayName: account.displayName ?? account.email,
      photoUrl: account.photoUrl,
    );
    await _refreshToken();
    notifyListeners();
  }

  Future<void> _refreshToken() async {
    final account = _account;
    if (account == null) return;
    final auth = await account.authentication;
    _accessToken = auth.accessToken;
    _tokenExpiry = DateTime.now().add(const Duration(minutes: 50));
  }

  /// Returns a valid access token, refreshing it when it is close to expiring.
  Future<String?> validAccessToken() async {
    if (_account == null) return null;
    final expiry = _tokenExpiry;
    if (_accessToken == null ||
        expiry == null ||
        DateTime.now().isAfter(expiry.subtract(const Duration(minutes: 5)))) {
      try {
        await _refreshToken();
      } catch (_) {
        return null;
      }
    }
    return _accessToken;
  }

  Future<bool> signIn() async {
    _setBusy(true);
    _lastError = null;
    try {
      final account = await _googleSignIn.signIn();
      if (account == null) {
        _lastError = 'Sign-in cancelled';
        return false;
      }
      await _adopt(account);
      return true;
    } catch (e) {
      _lastError = _friendlyError(e);
      return false;
    } finally {
      _setBusy(false);
    }
  }

  /// Silent sign-in on app start; never shows UI.
  Future<bool> signInSilently() async {
    try {
      final account = await _googleSignIn.signInSilently();
      if (account == null) return false;
      await _adopt(account);
      return true;
    } catch (e) {
      _lastError = _friendlyError(e);
      return false;
    }
  }

  Future<void> signOut() async {
    try {
      await _googleSignIn.signOut();
    } catch (_) {}
    await _adopt(null);
  }

  String _friendlyError(Object e) {
    final text = e.toString();
    if (text.contains('sign_in_failed') || text.contains('ApiException: 10')) {
      return 'Google Sign-In is not configured for this build '
          '(no OAuth client for package com.bookspeaker.app). '
          'The app keeps working offline — progress is saved locally.';
    }
    if (text.contains('network')) {
      return 'No internet connection.';
    }
    return text;
  }
}

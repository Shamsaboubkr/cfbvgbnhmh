/// Observable authentication state for the UI.
library;

import 'package:flutter/foundation.dart';

import 'google_sign_in_service.dart';

enum AuthMode { localOnly, signedOut, signedIn }

class AuthState extends ChangeNotifier {
  AuthState(this.service) {
    service.addListener(notifyListeners);
  }

  final GoogleSignInService service;

  AuthMode get mode {
    if (service.isSignedIn) return AuthMode.signedIn;
    return AuthMode.signedOut;
  }

  GoogleAuthUser? get user => service.user;
  bool get signedIn => service.isSignedIn;

  Future<bool> signIn() => service.signIn();
  Future<void> signOut() => service.signOut();
  Future<bool> trySilentSignIn() => service.signInSilently();
  Future<String?> validAccessToken() => service.validAccessToken();

  @override
  void dispose() {
    service.removeListener(notifyListeners);
    super.dispose();
  }
}

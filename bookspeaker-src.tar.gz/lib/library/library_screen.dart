/// Screen 4 — Library (home).
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_state.dart';
import '../player/player_screen.dart';
import '../widgets/book_cover.dart';
import '../widgets/cover_lookup_sheet.dart';
import '../widgets/cover_suggestion.dart';
import '../widgets/empty_states.dart';
import '../widgets/sync_indicator.dart';
import 'book_model.dart';

class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Library'),
        actions: [
          IconButton(
            tooltip: 'Search',
            icon: const Icon(Icons.search),
            onPressed: () => _openSearch(context),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 4),
            child: Center(child: const SyncIndicator()),
          ),
          _AccountAvatar(state: state),
        ],
      ),
      body: state.books.isEmpty
          ? const EmptyLibrary()
          : RefreshIndicator(
              onRefresh: state.rescan,
              child: ListView(
                padding: const EdgeInsets.only(bottom: 120),
                children: [
                  if (state.scanning)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: LinearProgressIndicator(
                        value: state.scanTotal == 0
                            ? null
                            : state.scanDone / state.scanTotal,
                      ),
                    ),
                  if (state.coverOffers.isNotEmpty)
                    CoverSuggestionBanner(offers: state.coverOffers),
                  _ContinueListening(state: state),
                  _RecentRow(state: state),
                  _FolderSections(state: state),
                  _AllBooks(state: state),
                ],
              ),
            ),
    );
  }

  static void _openSearch(BuildContext context) {
    final state = context.read<AppState>();
    showSearch<Object?>(
      context: context,
      delegate: _LibrarySearchDelegate(state),
    );
  }
}

class _LibrarySearchDelegate extends SearchDelegate<Object?> {
  _LibrarySearchDelegate(this.state);
  final AppState state;

  @override
  List<Widget> buildActions(BuildContext context) => [
        if (query.isNotEmpty)
          IconButton(icon: const Icon(Icons.clear), onPressed: () => query = ''),
      ];

  @override
  Widget buildLeading(BuildContext context) => IconButton(
        icon: const Icon(Icons.arrow_back),
        onPressed: () => close(context, null),
      );

  @override
  Widget buildResults(BuildContext context) {
    state.searchQuery = query;
    final results = state.searchedBooks;
    if (results.isEmpty) {
      return const Center(child: Text('No matches'));
    }
    return ListView(
      children: results
          .map((book) => ListTile(
                leading: SizedBox(
                  width: 40,
                  height: 40,
                  child: BookCover(book: book, showProgressBar: false, radius: 6),
                ),
                title: Text(book.title),
                subtitle: Text(book.author.isEmpty ? book.folderName : book.author),
                onTap: () {
                  // Capture the outer navigator *before* closing the search
                  // route — closing first and pushing straight after used to
                  // leave the app on a blank screen.
                  final navigator = Navigator.of(context, rootNavigator: true);
                  close(context, null);
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    navigator.push(MaterialPageRoute(
                        builder: (_) => PlayerScreen(book: book)));
                  });
                },
              ))
          .toList(),
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) => buildResults(context);
}

class _AccountAvatar extends StatelessWidget {
  const _AccountAvatar({required this.state});
  final AppState state;

  @override
  Widget build(BuildContext context) {
    final user = state.auth.user;
    return PopupMenuButton<String>(
      tooltip: 'Account',
      onSelected: (value) async {
        switch (value) {
          case 'signout':
            await state.signOut();
            break;
          case 'signin':
            await state.signIn();
            break;
          case 'sync':
            await state.forceSync();
            break;
        }
      },
      itemBuilder: (context) => [
        PopupMenuItem(
          enabled: false,
          child: ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            leading: CircleAvatar(
              backgroundImage:
                  user?.photoUrl != null ? NetworkImage(user!.photoUrl!) : null,
              child: user?.photoUrl == null ? const Icon(Icons.person) : null,
            ),
            title: Text(user?.displayName ?? 'Not signed in'),
            subtitle: Text(user?.email ?? 'Local-only mode'),
          ),
        ),
        if (user != null) ...[
          const PopupMenuDivider(),
          const PopupMenuItem(value: 'sync', child: Text('Force sync now')),
          const PopupMenuItem(value: 'signout', child: Text('Sign out')),
        ] else
          const PopupMenuItem(value: 'signin', child: Text('Sign in with Google')),
      ],
      child: Padding(
        padding: const EdgeInsets.only(right: 12, left: 4),
        child: CircleAvatar(
          radius: 16,
          backgroundImage:
              user?.photoUrl != null ? NetworkImage(user!.photoUrl!) : null,
          child: user?.photoUrl == null
              ? const Icon(Icons.person, size: 18)
              : null,
        ),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader(this.title, {this.trailing});
  final String title;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 22, 16, 10),
        child: Row(
          children: [
            Text(title,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const Spacer(),
            if (trailing != null) trailing!,
          ],
        ),
      );
}

class _ContinueListening extends StatelessWidget {
  const _ContinueListening({required this.state});
  final AppState state;

  @override
  Widget build(BuildContext context) {
    final book = state.continueListening;
    if (book == null) return const SizedBox.shrink();
    final progress = state.progressFor(book.bookId);
    final fraction = state.progressFraction(book);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _SectionHeader('Continue Listening'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Card(
            child: InkWell(
              onTap: () => _openBook(context, state, book),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    SizedBox(
                      width: 92,
                      height: 92,
                      child: BookCover(book: book, progress: fraction, radius: 12),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(book.title,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.w800)),
                          if (book.author.isNotEmpty) ...[
                            const SizedBox(height: 2),
                            Text(book.author,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: Theme.of(context).textTheme.bodySmall),
                          ],
                          const SizedBox(height: 10),
                          LinearProgressIndicator(
                            value: fraction,
                            minHeight: 5,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            progress == null
                                ? 'Not started'
                                : '${formatDuration(progress.remaining, hours: false)} left'
                                    ' • ${progress.percentComplete.toStringAsFixed(0)}%'
                                    ' • ${progress.playbackSpeed}x',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.play_circle_fill, size: 42),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _RecentRow extends StatelessWidget {
  const _RecentRow({required this.state});
  final AppState state;

  @override
  Widget build(BuildContext context) {
    final recent = state.recentBooks;
    if (recent.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _SectionHeader('Recent Books'),
        SizedBox(
          height: 168,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: recent.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, i) {
              final book = recent[i];
              return SizedBox(
                width: 104,
                child: GestureDetector(
                  onTap: () => _openBook(context, state, book),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 130,
                        child: BookCover(
                          book: book,
                          progress: state.progressFraction(book),
                          radius: 10,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(book.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.bodySmall),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _FolderSections extends StatelessWidget {
  const _FolderSections({required this.state});
  final AppState state;

  @override
  Widget build(BuildContext context) {
    final sections = state.folderSections
        .where((s) => s.books.isNotEmpty || s.path.isNotEmpty)
        .toList();
    if (sections.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _SectionHeader('Folders'),
        ...sections.map((section) => Card(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              child: ListTile(
                leading: const Icon(Icons.folder_outlined),
                title: Text(section.name),
                subtitle: Text('${section.books.length} book'
                    '${section.books.length == 1 ? '' : 's'}'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => FolderViewScreen(section: section),
                )),
              ),
            )),
      ],
    );
  }
}

class FolderViewScreen extends StatelessWidget {
  const FolderViewScreen({super.key, required this.section});
  final FolderSection section;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final books = state.books
        .where((b) => section.books.any((s) => s.bookId == b.bookId))
        .toList();
    return Scaffold(
      appBar: AppBar(title: Text(section.name)),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 160,
          childAspectRatio: 0.62,
          crossAxisSpacing: 14,
          mainAxisSpacing: 14,
        ),
        itemCount: books.length,
        itemBuilder: (context, i) => _BookTile(
          book: books[i],
          progress: state.progressFraction(books[i]),
        ),
      ),
    );
  }
}

class _AllBooks extends StatelessWidget {
  const _AllBooks({required this.state});
  final AppState state;

  @override
  Widget build(BuildContext context) {
    final books = state.searchedBooks;
    if (books.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _SectionHeader('All Books',
            trailing: Text('${books.length}',
                style: Theme.of(context).textTheme.bodySmall)),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 16),
          gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
            maxCrossAxisExtent: 170,
            childAspectRatio: 0.6,
            crossAxisSpacing: 14,
            mainAxisSpacing: 16,
          ),
          itemCount: books.length,
          itemBuilder: (context, i) => _BookTile(
            book: books[i],
            progress: state.progressFraction(books[i]),
          ),
        ),
      ],
    );
  }
}

class _BookTile extends StatelessWidget {
  const _BookTile({required this.book, required this.progress});
  final Book book;
  final double progress;

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();
    return GestureDetector(
      onTap: () {
        if (!book.isAvailable) {
          showMissingFileSheet(context, book);
        } else {
          _openBook(context, state, book);
        }
      },
      onLongPress: () => _showBookOptions(context, state, book),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(child: BookCover(book: book, progress: progress, radius: 12)),
          const SizedBox(height: 8),
          Text(book.title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
          if (book.author.isNotEmpty)
            Text(book.author,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.bodySmall),
        ],
      ),
    );
  }
}

void _openBook(BuildContext context, AppState state, Book book) {
  Navigator.of(context).push(
    MaterialPageRoute(builder: (_) => PlayerScreen(book: book)),
  );
}

/// Long-press menu on a book card.
Future<void> _showBookOptions(BuildContext context, AppState state, Book book) async {
  await showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    builder: (sheetContext) => SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.image_outlined),
            title: const Text('Set Cover Art'),
            onTap: () {
              Navigator.pop(sheetContext);
              state.setCoverFromFilePicker(book);
            },
          ),
          ListTile(
            leading: const Icon(Icons.travel_explore),
            title: const Text('Look Up Cover Online'),
            subtitle: const Text('OpenLibrary, Google Books, iTunes'),
            onTap: () {
              Navigator.pop(sheetContext);
              // Opens immediately with a spinner, then shows the result (or the
              // reason nothing was found) — never a silent no-op.
              showCoverLookupSheet(context, state, book);
            },
          ),
          ListTile(
            leading: const Icon(Icons.delete_outline),
            title: const Text('Remove from Library'),
            onTap: () {
              Navigator.pop(sheetContext);
              state.removeFromLibrary(book);
            },
          ),
        ],
      ),
    ),
  );
}

/// Library scanning: walks watched folders, fingerprints new audio files,
/// reads tags, extracts covers and keeps `is_available` flags accurate.
///
/// Everything expensive happens off the UI thread: directory walks are async
/// and tag reads run in a background isolate, so scrolling and taps stay
/// responsive even with a large library.
library;

import 'dart:async';
import 'dart:io';
import 'dart:isolate';

import 'package:audio_metadata_reader/audio_metadata_reader.dart';
import 'package:path/path.dart' as p;

import '../covers/cover_art_service.dart';
import '../data/db.dart';
import 'book_model.dart';
import 'fingerprint_service.dart';

const supportedExtensions = ['mp3', 'm4a', 'm4b', 'opus', 'ogg', 'aac', 'flac', 'wav'];

class ScanResult {
  final int added;
  final int refreshed;
  final int missing;
  final List<Book> books;
  const ScanResult({
    required this.added,
    required this.refreshed,
    required this.missing,
    required this.books,
  });
}

/// Tag values pulled out of a file in a background isolate.
typedef _Tags = ({String title, String author, int durationMs});

class BookScanner {
  BookScanner(this.db, this.covers);

  final BookspeakerDb db;
  final CoverArtService covers;

  static bool _isAudio(String path) {
    final ext = p.extension(path).toLowerCase().replaceFirst('.', '');
    return supportedExtensions.contains(ext);
  }

  static bool _isHidden(String path) =>
      p.split(path).any((seg) => seg.startsWith('.'));

  /// Asynchronously finds audio files in [folder] (skips hidden dirs).
  static Future<List<File>> findAudioFilesAsync(String folder) async {
    final dir = Directory(folder);
    if (!await dir.exists()) return [];
    final out = <File>[];
    await for (final entity
        in dir.list(recursive: true, followLinks: false)) {
      if (entity is! File) continue;
      final path = entity.path;
      if (_isHidden(path) || !_isAudio(path)) continue;
      out.add(entity);
    }
    out.sort((a, b) => a.path.compareTo(b.path));
    return out;
  }

  /// Synchronous variant for tiny checks (single directory listings).
  static List<File> findAudioFiles(String folder) {
    final dir = Directory(folder);
    if (!dir.existsSync()) return [];
    final out = <File>[];
    try {
      for (final entity in dir.listSync(recursive: true, followLinks: false)) {
        if (entity is! File) continue;
        if (_isHidden(entity.path) || !_isAudio(entity.path)) continue;
        out.add(entity);
      }
    } catch (_) {}
    out.sort((a, b) => a.path.compareTo(b.path));
    return out;
  }

  /// Full library scan across every watched folder.
  Future<ScanResult> scanLibrary(
    List<String> folders, {
    void Function(int done, int total)? onProgress,
  }) async {
    final files = <File>[];
    for (final folder in folders) {
      files.addAll(await findAudioFilesAsync(folder));
    }

    final known = {for (final b in db.allBooks()) b.filePath: b};
    var added = 0;
    var refreshed = 0;

    for (var i = 0; i < files.length; i++) {
      final file = files[i];
      onProgress?.call(i + 1, files.length);
      try {
        final existing = known[file.path];
        if (existing != null) {
          if (!existing.isAvailable) {
            db.markAvailable(existing.bookId, file.path);
          }
          continue;
        }
        final result = await ingestFile(file);
        if (result == IngestResult.added) added++;
        if (result == IngestResult.relinked) refreshed++;
      } catch (_) {
        // Skip unreadable files, keep the rest of the library usable.
      }
    }

    // Anything tracked but no longer on disk → grey out (progress kept).
    var missing = 0;
    final present = files.map((f) => f.path).toSet();
    for (final book in db.allBooks()) {
      if (!book.isAvailable) continue;
      final pathIsWatched = folders.any(
          (f) => p.isWithin(f, book.filePath) || p.equals(f, book.filePath));
      if (!pathIsWatched) continue;
      final exists = present.contains(book.filePath)
          ? true
          : await File(book.filePath).exists();
      if (!exists) {
        db.markUnavailable(book.bookId);
        missing++;
      }
    }

    return ScanResult(
      added: added,
      refreshed: refreshed,
      missing: missing,
      books: db.allBooks(),
    );
  }

  /// Reads tags in a background isolate so the UI thread never blocks on file
  /// I/O (this used to freeze the app for seconds on a big library).
  static Future<_Tags> readTags(String path) {
    return Isolate.run(() {
      try {
        final meta = readMetadata(File(path));
        return (
          title: (meta.title ?? '').trim(),
          author: (meta.artist ?? '').trim(),
          durationMs: meta.duration?.inMilliseconds ?? 0,
        );
      } catch (_) {
        return (title: '', author: '', durationMs: 0);
      }
    });
  }

  /// Fingerprints one file and inserts/re-links it in the database.
  Future<IngestResult> ingestFile(File file, {bool fetchCover = true}) async {
    final ext = p.extension(file.path).toLowerCase().replaceFirst('.', '');
    final format = AudioFormatX.fromExtension(file.path) ??
        (ext == 'ogg' ? AudioFormat.opus : AudioFormat.mp3);

    final bookId = await FingerprintService.fingerprintOffThread(file.path);

    final existingById = db.book(bookId);
    if (existingById != null) {
      // Same audio, new path → re-link silently, progress survives.
      if (existingById.filePath != file.path || !existingById.isAvailable) {
        db.upsertBook(existingById.copyWith(
          filePath: file.path,
          folderName: p.basename(p.dirname(file.path)),
          isAvailable: true,
        ));
        return IngestResult.relinked;
      }
      return IngestResult.unchanged;
    }

    var title = p.basenameWithoutExtension(file.path);
    var author = '';
    var duration = Duration.zero;

    final tags = await readTags(file.path);
    if (tags.title.isNotEmpty) title = tags.title;
    if (tags.author.isNotEmpty) author = tags.author;
    duration = Duration(milliseconds: tags.durationMs);

    final book = Book(
      bookId: bookId,
      title: cleanTitle(title),
      author: author,
      filePath: file.path,
      folderName: p.basename(p.dirname(file.path)),
      format: format,
      totalDuration: duration,
      dateAdded: DateTime.now(),
      isAvailable: true,
    );

    db.upsertBook(book);
    db.ensureProgress(book);
    if (fetchCover) {
      unawaited(covers.resolveLocalCover(book).then((path) {
        if (path != null) {
          db.setCoverPath(book.bookId, path);
        } else {
          db.markCoverChecked(book.bookId);
        }
      }));
    }
    return IngestResult.added;
  }

  /// "01 - The Great Gatsby" → "The Great Gatsby"
  static String cleanTitle(String raw) {
    var t = raw.replaceAll('_', ' ').trim();
    t = t.replaceFirst(RegExp(r'^\s*\d{1,3}\s*[-–.)]\s*'), '');
    return t.isEmpty ? raw : t;
  }
}

enum IngestResult { added, relinked, unchanged }

/// SHA-256 audio fingerprinting.
///
/// The book ID must survive renames, moves and tag edits but change when the
/// audio itself changes. Algorithm (exactly as specified):
///
/// 1. Open the file.
/// 2. Skip past the metadata header (ID3v2 / MP4 `ftyp+moov` / Ogg prefix).
/// 3. Read 1 MB from the start of the audio payload.
/// 4. Read 1 MB from the end of the file.
/// 5. Note the size of that audio payload in bytes.
/// 6. SHA-256(first1MB + last1MB + payloadSizeString) → first 16 hex chars.
///
/// Note on step 5: the specification says "exact file size", but the app itself
/// embeds cover art into the file (ID3 APIC), which changes the container size
/// while leaving the audio untouched. Hashing the *payload* size (file size
/// minus the metadata header) keeps the spec's guarantee that "tags edited →
/// same ID" true for our own writes as well, and still changes the ID whenever
/// the audio itself changes.
library;

import 'dart:io';
import 'dart:isolate';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';

class FingerprintService {
  static const int chunkSize = 1024 * 1024; // 1 MB
  static const int idLength = 16; // first 16 hex chars

  /// Runs [fingerprint] on a worker isolate — hashing 2 MB and reading a large
  /// file must not block the UI thread during a library scan.
  static Future<String> fingerprintOffThread(String filePath) =>
      Isolate.run(() => fingerprint(filePath));

  /// Returns the 16-character book ID for [filePath].
  static Future<String> fingerprint(String filePath) async {
    final file = File(filePath);
    final size = await file.length();
    final raf = await file.open();

    try {
      final dataStart = await _audioDataStart(raf);
      final first = await _readAt(raf, dataStart, chunkSize);
      // Never let the tail read reach back into the metadata header.
      final tailStart = (size - chunkSize).clamp(dataStart, size);
      final last = await _readAt(raf, tailStart, size - tailStart);
      final payloadSize = size - dataStart;

      final builder = BytesBuilder(copy: false)
        ..add(first)
        ..add(last)
        ..add(Uint8List.fromList('$payloadSize'.codeUnits));

      final digest = sha256.convert(builder.takeBytes());
      return digest.toString().substring(0, idLength);
    } finally {
      await raf.close();
    }
  }

  static Future<Uint8List> _readAt(RandomAccessFile raf, int start, int length) async {
    if (length <= 0) return Uint8List(0);
    await raf.setPosition(start);
    return Uint8List.fromList(await raf.read(length));
  }

  /// Offset where the raw audio payload begins (after container metadata).
  static Future<int> _audioDataStart(RandomAccessFile raf) async {
    await raf.setPosition(0);
    final head = Uint8List.fromList(await raf.read(4096));
    if (head.length < 12) return 0;

    // ID3v2 header: "ID3" + version(2) + flags(1) + syncsafe size(4)
    if (head[0] == 0x49 && head[1] == 0x44 && head[2] == 0x33) {
      final size = ((head[6] & 0x7F) << 21) |
          ((head[7] & 0x7F) << 14) |
          ((head[8] & 0x7F) << 7) |
          (head[9] & 0x7F);
      final footer = (head[5] & 0x10) != 0 ? 10 : 0;
      return (10 + size + footer).clamp(0, 1 << 62);
    }

    // MP4 / M4A: skip to the end of the moov atom so the hash covers mdat.
    if (_ascii(head, 4, 4) == 'ftyp') {
      final moovEnd = _findAtomEnd(head, 'moov');
      if (moovEnd > 0) return moovEnd;
      return 4096;
    }

    // Ogg (Opus): skip the two header pages.
    if (_ascii(head, 0, 4) == 'OggS') {
      return _oggHeadersEnd(head);
    }

    // FLAC: "fLaC" + metadata blocks.
    if (_ascii(head, 0, 4) == 'fLaC') {
      var offset = 4;
      while (offset + 4 <= head.length) {
        final isLast = (head[offset] & 0x80) != 0;
        final len = (head[offset + 1] << 16) | (head[offset + 2] << 8) | head[offset + 3];
        offset += 4 + len;
        if (isLast) break;
      }
      return offset;
    }

    // MPEG frame sync (bare MP3 without ID3), or unknown: use 0.
    return 0;
  }

  static String _ascii(Uint8List b, int start, int length) {
    if (start + length > b.length) return '';
    return String.fromCharCodes(b.sublist(start, start + length));
  }

  static int _findAtomEnd(Uint8List head, String type) {
    var offset = 0;
    while (offset + 8 <= head.length) {
      final size = (head[offset] << 24) |
          (head[offset + 1] << 16) |
          (head[offset + 2] << 8) |
          head[offset + 3];
      final name = _ascii(head, offset + 4, 4);
      if (name == type) return offset + (size <= 0 ? 8 : size);
      if (size <= 8) return -1; // malformed / extends-container
      offset += size;
    }
    return -1;
  }

  /// Walks Ogg pages until the first audio page begins (after the two header
  /// pages that carry OpusHead / OpusTags).
  static int _oggHeadersEnd(Uint8List head) {
    var offset = 0;
    var pages = 0;
    while (offset + 27 <= head.length && pages < 3) {
      if (_ascii(head, offset, 4) != 'OggS') break;
      final segments = head[offset + 26];
      final tableEnd = offset + 27 + segments;
      if (tableEnd > head.length) break;
      var bodyLen = 0;
      for (var i = 0; i < segments; i++) {
        bodyLen += head[offset + 27 + i];
      }
      offset = tableEnd + bodyLen;
      pages++;
      // OpusTags is the 2nd page; audio starts after it.
      if (pages >= 2) break;
    }
    return offset;
  }
}

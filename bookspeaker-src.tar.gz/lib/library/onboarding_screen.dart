/// Screens 1-3 of the flow: splash/sign-in → folder picker → scan results.
/// Shown only on first launch, or whenever the library has no folders yet.
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_state.dart';
import '../widgets/book_cover.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  int _step = 0;
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = Theme.of(context);

    return Scaffold(
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 350),
        child: switch (_step) {
          0 => _welcome(context, state, theme),
          1 => _folderPicker(context, state, theme),
          _ => _scanResults(context, state, theme),
        },
      ),
    );
  }

  // ------------------------------------------------------------- step 1

  Widget _welcome(BuildContext context, AppState state, ThemeData theme) {
    return SafeArea(
      key: const ValueKey('welcome'),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 132,
              height: 132,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF4A3580), Color(0xFF2A1D4D)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(32),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF4A3580).withOpacity(0.35),
                    blurRadius: 28,
                    offset: const Offset(0, 12),
                  ),
                ],
              ),
              child: const Icon(Icons.headphones, size: 66, color: Color(0xFFC4A35A)),
            ),
            const SizedBox(height: 28),
            Text('Bookspeaker',
                style: theme.textTheme.headlineMedium
                    ?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Text('Listen everywhere. Pick up anywhere.',
                style: theme.textTheme.bodyLarge),
            const SizedBox(height: 44),
            FilledButton.icon(
              onPressed: _busy
                  ? null
                  : () async {
                      setState(() => _busy = true);
                      final ok = await state.signIn();
                      setState(() => _busy = false);
                      if (!context.mounted) return;
                      if (!ok) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text(state.auth.lastError ??
                              'Could not sign in. You can continue offline.'),
                        ));
                      }
                      setState(() => _step = 1);
                    },
              icon: _busy
                  ? const SizedBox(
                      width: 18, height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.login),
              label: const Text('Continue with Google'),
            ),
            const SizedBox(height: 12),
            OutlinedButton(
              onPressed: () => setState(() => _step = 1),
              child: const Text('Continue without signing in'),
            ),
            const SizedBox(height: 20),
            Text(
              'Progress syncs through your own Google Drive. '
              'Audio files never leave your device.',
              textAlign: TextAlign.center,
              style: theme.textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------- step 2

  Widget _folderPicker(BuildContext context, AppState state, ThemeData theme) {
    return SafeArea(
      key: const ValueKey('folder'),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.folder_open, size: 64),
            const SizedBox(height: 18),
            Text('Where are your audiobooks?',
                textAlign: TextAlign.center,
                style: theme.textTheme.headlineSmall
                    ?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text(
              'Bookspeaker watches the folder you choose and keeps the library '
              'in sync automatically.',
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyMedium,
            ),
            const SizedBox(height: 26),
            FilledButton.icon(
              onPressed: _busy
                  ? null
                  : () async {
                      setState(() => _busy = true);
                      await state.addFolderViaPicker();
                      setState(() => _busy = false);
                      if (state.folders.isNotEmpty) setState(() => _step = 2);
                    },
              icon: const Icon(Icons.folder_open),
              label: const Text('Browse for folder'),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () async {
                await state.addFilesViaPicker();
                if (state.folders.isNotEmpty) setState(() => _step = 2);
              },
              icon: const Icon(Icons.audio_file),
              label: const Text('Pick audio files instead'),
            ),
            const SizedBox(height: 20),
            if (state.folders.isNotEmpty)
              Column(
                children: state.folders
                    .map((f) => ListTile(
                          dense: true,
                          leading: const Icon(Icons.check_circle_outline),
                          title: Text(f, maxLines: 1, overflow: TextOverflow.ellipsis),
                        ))
                    .toList(),
              ),
            const Spacer(),
            if (_busy) const LinearProgressIndicator(),
            Padding(
              padding: const EdgeInsets.only(bottom: 20),
              child: TextButton(
                onPressed: state.folders.isEmpty
                    ? null
                    : () => setState(() => _step = 2),
                child: const Text('Start listening'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------- step 3

  Widget _scanResults(BuildContext context, AppState state, ThemeData theme) {
    final found = state.books;
    return SafeArea(
      key: const ValueKey('results'),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 12),
            Text('Found ${found.length} audiobook${found.length == 1 ? '' : 's'}!',
                style: theme.textTheme.headlineSmall
                    ?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text('Progress for each one is tracked separately.',
                style: theme.textTheme.bodyMedium),
            const SizedBox(height: 18),
            if (state.scanning)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  LinearProgressIndicator(
                    value: state.scanTotal == 0
                        ? null
                        : state.scanDone / state.scanTotal,
                  ),
                  const SizedBox(height: 8),
                  Text('Scanning ${state.scanDone} of ${state.scanTotal}…'),
                ],
              ),
            Expanded(
              child: found.isEmpty
                  ? Center(
                      child: Text(
                        'No audio files found in that folder yet.\n'
                        'Add MP3, M4A or Opus files and they will appear here.',
                        textAlign: TextAlign.center,
                        style: theme.textTheme.bodyMedium,
                      ),
                    )
                  : GridView.builder(
                      gridDelegate:
                          const SliverGridDelegateWithMaxCrossAxisExtent(
                        maxCrossAxisExtent: 140,
                        childAspectRatio: 0.66,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                      ),
                      itemCount: found.length,
                      itemBuilder: (context, i) {
                        final book = found[i];
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: BookCover(
                                book: book,
                                showProgressBar: false,
                                radius: 10,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(book.title,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: theme.textTheme.bodySmall),
                          ],
                        );
                      },
                    ),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () => state.completeOnboarding(),
              child: const Text('Go to my library'),
            ),
          ],
        ),
      ),
    );
  }
}

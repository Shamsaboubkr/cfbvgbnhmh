/// Central application state: owns the services and exposes everything the UI
/// screens need. Registered with `provider` at the root of the widget tree.
///
/// This object deliberately does **not** listen to playback position changes —
/// playback updates go through [AudioPlayerService] (its own provider) so that
/// the library, bookmarks and settings screens stay still while audio plays.
///
/// User-visible feedback goes through [toast] → a stream that the app shell
/// renders as snack bars. (Earlier builds stored those messages in a field that
/// nothing displayed, which made failed actions look like nothing happened.)
library;

import 'dart:async';
import 'dart:io';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:permission_handler/permission_handler.dart';

import 'app/theme/dynamic_theme.dart';
import 'auth/auth_state.dart';
import 'auth/google_sign_in_service.dart';
import 'covers/cover_art_service.dart';
import 'covers/cover_sources/image_validation.dart';
import 'covers/cover_sources/openlibrary_source.dart';
import 'data/db.dart';
import 'library/book_model.dart';
import 'library/book_scanner.dart';
import 'library/folder_watcher.dart';
import 'player/audio_player_service.dart';
import 'player/sleep_timer_service.dart';
import 'progress/drive_sync_service.dart';
import 'progress/local_storage_service.dart';

class FolderSection {
  final String name;
  final String path;
  final List<Book> books;
  const FolderSection(this.name, this.path, this.books);
}

/// A cover found online, waiting for the user's yes/no.
class CoverOffer {
  final Book book;
  final CoverCandidate candidate;
  const CoverOffer(this.book, this.candidate);
}

class AppState extends ChangeNotifier {
  AppState({
    required this.local,
    required this.auth,
    required this.authState,
    required this.sync,
    required this.theme,
    required this.player,
    required this.sleepTimer,
    required this.scanner,
    required this.watcher,
    required this.covers,
  });

  final LocalStorageService local;
  final GoogleSignInService auth;
  final AuthState authState;
  final DriveSyncService sync;
  final ThemeController theme;
  final AudioPlayerService player;
  final SleepTimerService sleepTimer;
  final BookScanner scanner;
  final FolderWatcherService watcher;
  final CoverArtService covers;

  bool initializing = true;
  bool scanning = false;
  int scanDone = 0;
  int scanTotal = 0;
  String? lastScanSummary;
  ScanResult? lastScanResult;
  String searchQuery = '';

  /// Online covers waiting for confirmation — surfaced as a dismissible card on
  /// the library screen, never as a modal dialog over the player.
  final List<CoverOffer> coverOffers = [];

  // ------------------------------------------------------------ messaging

  final StreamController<String> _messages = StreamController<String>.broadcast();

  /// Snack-bar messages that the app shell displays.
  Stream<String> get messages => _messages.stream;

  void toast(String message) {
    if (message.trim().isEmpty) return;
    _messages.add(message);
  }

  void notify() => notifyListeners();

  List<Book> get books => local.db.allBooks();

  BookspeakerDb get db => local.db;

  // ------------------------------------------------------------- lifecycle

  Future<void> bootstrap() async {
    theme
      ..setMode(_parseThemeMode(local.themeMode))
      ..setDynamicColor(local.dynamicColor);

    sync.addListener(notifyListeners);
    auth.addListener(notifyListeners);

    await player.init();
    sleepTimer.onElapsed = () {
      player.pause();
      toast('Sleep timer finished — playback paused');
    };
    sleepTimer.onFade = (v) => player.setVolume(v);

    _listenConnectivity();

    // Get the UI on screen first; the potentially slow work happens after.
    initializing = false;
    notifyListeners();

    unawaited(_postStart());
  }

  /// Runs after the first frame so startup never feels stuck.
  Future<void> _postStart() async {
    try {
      await watcher.startAll();
      watcher.changes.listen((_) => notifyListeners());

      if (local.db.watchedFolders().isNotEmpty && _scanIsStale) {
        await rescan(silent: true);
      }
    } catch (_) {}

    if (!local.signedOutOnPurpose) {
      final ok = await auth.signInSilently();
      if (ok) unawaited(sync.syncNow());
      notifyListeners();
    } else {
      unawaited(sync.syncNow());
    }
  }

  /// A scan is skipped when one finished within the last 30 seconds, which
  /// keeps reopening the app fast.
  bool get _scanIsStale {
    final raw = local.db.getSetting('last_scan_at');
    if (raw == null) return true;
    final last = DateTime.tryParse(raw);
    if (last == null) return true;
    return DateTime.now().difference(last) > const Duration(seconds: 30);
  }

  void _listenConnectivity() {
    try {
      Connectivity().onConnectivityChanged.listen((results) {
        final online = results.any((r) => r != ConnectivityResult.none);
        if (online) sync.onConnectivityChanged();
      });
    } catch (_) {}
  }

  ThemeMode _parseThemeMode(String value) => switch (value) {
        'light' => ThemeMode.light,
        'dark' => ThemeMode.dark,
        _ => ThemeMode.system,
      };

  // ------------------------------------------------------------- library

  List<String> get folders => watcher.watchedPaths;

  List<Book> get availableBooks => books.where((b) => b.isAvailable).toList();

  List<Book> get searchedBooks {
    if (searchQuery.trim().isEmpty) return books;
    final q = searchQuery.toLowerCase();
    return books
        .where((b) =>
            b.title.toLowerCase().contains(q) ||
            b.author.toLowerCase().contains(q) ||
            b.folderName.toLowerCase().contains(q))
        .toList();
  }

  BookProgress? progressFor(String bookId) => local.db.progressFor(bookId);

  double progressFraction(Book book) {
    final pr = progressFor(book.bookId);
    if (pr == null || pr.totalDuration_ms <= 0) return 0;
    return (pr.position_ms / pr.totalDuration_ms).clamp(0.0, 1.0);
  }

  /// Fresh copy of a book (cover path etc. may have changed since it was read).
  Book? book(String bookId) => db.book(bookId);

  /// "Continue Listening" — the most recently played book with real progress.
  Book? get continueListening {
    final played = books.where((b) {
      final pr = progressFor(b.bookId);
      return pr != null && pr.position_ms > 0 && !pr.finished;
    }).toList();
    if (played.isEmpty) return null;
    played.sort((a, b) {
      final pa = progressFor(a.bookId)!.lastPlayed;
      final pb = progressFor(b.bookId)!.lastPlayed;
      return pb.compareTo(pa);
    });
    return played.first;
  }

  List<Book> get recentBooks {
    final played =
        books.where((b) => (progressFor(b.bookId)?.position_ms ?? 0) > 0).toList();
    played.sort((a, b) {
      final pa = progressFor(a.bookId)?.lastPlayed ?? DateTime(2000);
      final pb = progressFor(b.bookId)?.lastPlayed ?? DateTime(2000);
      return pb.compareTo(pa);
    });
    return played.take(12).toList();
  }

  List<FolderSection> get folderSections {
    final sections = <FolderSection>[];
    for (final folder in folders) {
      final inFolder = books
          .where((b) =>
              p.isWithin(folder, b.filePath) ||
              File(b.filePath).parent.path == folder)
          .toList();
      sections.add(FolderSection(p.basename(folder), folder, inFolder));
    }
    final orphans =
        books.where((b) => !folders.any((f) => p.isWithin(f, b.filePath))).toList();
    if (orphans.isNotEmpty) {
      final byFolder = <String, List<Book>>{};
      for (final b in orphans) {
        byFolder.putIfAbsent(b.folderName, () => []).add(b);
      }
      byFolder.forEach(
          (name, list) => sections.add(FolderSection(name, '', list)));
    }
    return sections;
  }

  Future<void> addFolder(String path) async {
    await _ensureReadable(path);
    await watcher.addFolder(path);
    await rescan();
    notifyListeners();
  }

  /// Asks for all-files access only when a chosen folder is actually unreadable
  /// (Android 11+), instead of requesting it up front at launch.
  Future<void> _ensureReadable(String path) async {
    try {
      Directory(path).listSync().take(1).toList();
    } catch (_) {
      try {
        final status = await Permission.manageExternalStorage.request();
        if (!status.isGranted) {
          toast('Access to that folder was denied — Bookspeaker will use the '
              'files it can read.');
        }
      } catch (_) {}
    }
  }

  Future<void> addFolderViaPicker() async {
    try {
      final picked = await FilePicker.platform.getDirectoryPath(
        dialogTitle: 'Where are your audiobooks?',
      );
      if (picked == null || picked.isEmpty) return;
      await addFolder(picked);
    } catch (e) {
      toast('Could not open the folder picker. You can pick your audiobook '
          'files instead.');
      await addFilesViaPicker();
    }
  }

  /// Fallback: pick the audio files, then watch their parent folder.
  Future<void> addFilesViaPicker() async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.custom,
      allowedExtensions: supportedExtensions,
    );
    final paths =
        result?.files.map((f) => f.path).whereType<String>().toList() ??
            const <String>[];
    if (paths.isEmpty) return;
    final parents = paths.map((f) => p.dirname(f)).toSet();
    for (final folder in parents) {
      await watcher.addFolder(folder);
      for (final path in paths.where((f) => p.dirname(f) == folder)) {
        try {
          await scanner.ingestFile(File(path));
        } catch (_) {}
      }
    }
    notifyListeners();
  }

  Future<void> removeFolder(String path) async {
    watcher.removeFolder(path);
    notifyListeners();
    await rescan(silent: true);
  }

  Future<ScanResult> rescan({bool silent = false}) async {
    scanning = true;
    scanDone = 0;
    scanTotal = 0;
    if (!silent) notifyListeners();

    final result = await scanner.scanLibrary(
      folders,
      onProgress: (done, total) {
        scanDone = done;
        scanTotal = total;
        if (!silent && total > 0 && done % 5 == 0) notifyListeners();
      },
    );

    scanning = false;
    lastScanResult = result;
    lastScanSummary = 'Found ${result.books.length} audiobooks';
    db.setSetting('last_scan_at', DateTime.now().toUtc().toIso8601String());

    unawaited(_resolveMissingCovers(result.books));
    notifyListeners();
    return result;
  }

  /// Resolves embedded/folder covers a few books at a time, in the background,
  /// so the UI never stalls (this used to run synchronously for every book).
  Future<void> _resolveMissingCovers(List<Book> all) async {
    final pending = all
        .where((b) => b.coverCachePath == null && !b.coverChecked && b.isAvailable)
        .take(6)
        .toList();
    for (final book in pending) {
      final path = await covers.resolveLocalCover(book);
      if (path != null) {
        db.setCoverPath(book.bookId, path);
      } else {
        db.markCoverChecked(book.bookId);
      }
      notifyListeners();
    }
  }

  void completeOnboarding() {
    local.onboardingDone = true;
    notifyListeners();
  }

  // -------------------------------------------------------------- player

  Future<void> openBook(Book book, {bool autoplay = true}) async {
    if (!book.isAvailable) return;

    // Quick Drive check for a newer position elsewhere (never blocks opening).
    unawaited(sync.pullForBook(book));

    await player.openBook(book, autoplay: autoplay);
    unawaited(_ensureCover(book));
    await theme.applyCover(db.book(book.bookId)?.coverCachePath);
    notifyListeners();
  }

  /// Local cover first (embedded → folder image). The online lookup happens in
  /// the background and only produces a *suggestion* — never a dialog in the
  /// middle of playback.
  Future<void> _ensureCover(Book book) async {
    final current = db.book(book.bookId);
    if (current == null) return;

    final existing = await covers.resolveLocalCover(current);
    if (existing != null) {
      db.setCoverPath(current.bookId, existing);
      await theme.applyCover(existing);
      player.refreshMediaItemCover(current.copyWith(coverCachePath: existing));
      notifyListeners();
      return;
    }
    if (current.coverChecked) return;

    final outcome = await covers.findOnlineCover(current);
    db.markCoverChecked(current.bookId);
    final candidate = outcome.candidate;
    if (candidate == null) return;

    coverOffers.removeWhere((o) => o.book.bookId == current.bookId);
    coverOffers.add(CoverOffer(current, candidate));
    toast('Cover found for ${current.title} — tap the suggestion in your library');
    notifyListeners();
  }

  void dismissCoverOffer(CoverOffer offer) {
    coverOffers.remove(offer);
    notifyListeners();
  }

  // --------------------------------------------------------------- covers

  /// Applies artwork bytes for [book]: caches them immediately (so the UI
  /// updates at once) and then writes them into the audio file in the
  /// background.
  Future<bool> applyCoverBytes(
    Book book,
    List<int> bytes, {
    required String source,
  }) async {
    if (bytes.isEmpty) {
      toast('That image is empty and could not be used');
      return false;
    }
    if (!CoverImage.looksLikeImage(bytes)) {
      toast('That file is not a supported image (JPEG or PNG please)');
      return false;
    }

    final path = await covers.cacheCover(book, bytes);
    if (path == null) {
      toast('Could not save that cover');
      return false;
    }

    // Paint it straight away — grid, player and media notification.
    final updated = book.copyWith(coverCachePath: path, coverChecked: true);
    await theme.applyCover(path);
    player.refreshMediaItemCover(updated);
    toast('Cover art updated from $source');
    notifyListeners();

    unawaited(_embedCoverInBackground(book, bytes));
    return true;
  }

  /// Writes the new artwork into the file itself so it travels with the MP3.
  Future<void> _embedCoverInBackground(Book book, List<int> bytes) async {
    if (book.format != AudioFormat.mp3) {
      toast('Saved in Bookspeaker. ${book.format.label.toUpperCase()} files '
          'cannot carry artwork inside the file yet.');
      return;
    }
    if (!File(book.filePath).existsSync()) {
      toast('Cover saved in Bookspeaker — the audio file itself is missing');
      return;
    }
    final ok = await covers.embedCover(book, bytes);
    toast(ok
        ? 'Cover written into ${p.basename(book.filePath)}'
        : 'Cover saved in Bookspeaker, but writing it into the file failed');
  }

  /// Manual override: pick an image from the device.
  Future<void> setCoverFromFilePicker(Book book) async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.image,
        allowMultiple: false,
        withData: true,
      );
      if (result == null || result.files.isEmpty) return; // user cancelled

      final picked = result.files.first;
      List<int>? bytes = picked.bytes;
      if (bytes == null && picked.path != null) {
        bytes = await covers.readImageFile(picked.path!);
      }
      if (bytes == null || bytes.isEmpty) {
        toast('Could not read that image — try another one');
        return;
      }
      await applyCoverBytes(book, bytes, source: 'your device');
    } catch (e) {
      toast('Could not set that cover: $e');
    }
  }

  /// Network-only lookup used by the preview sheet (no state changes).
  Future<CoverSearchOutcome> findCover(Book book) =>
      covers.findOnlineCover(book);

  /// On-demand online lookup. Returns the outcome so the caller can show the
  /// preview sheet (including *why* nothing was found).
  Future<CoverSearchOutcome> lookUpCoverOnline(Book book) async {
    toast('Looking for a cover for "${book.title}"…');
    final outcome = await covers.findOnlineCover(book);
    final candidate = outcome.candidate;
    if (candidate != null) {
      coverOffers.removeWhere((o) => o.book.bookId == book.bookId);
      coverOffers.add(CoverOffer(book, candidate));
      notifyListeners();
    } else {
      db.markCoverChecked(book.bookId);
    }
    return outcome;
  }

  Future<void> acceptCoverOffer(CoverOffer offer) async {
    final bytes = offer.candidate.bytes ?? const <int>[];
    coverOffers.remove(offer);
    await applyCoverBytes(offer.book, bytes, source: offer.candidate.source);
    notifyListeners();
  }

  // ------------------------------------------------------- missing files

  Future<void> locateFile(Book book) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: supportedExtensions,
    );
    final path = result?.files.single.path;
    if (path == null) return;
    final found = await watcher.relocateBook(book);
    if (found != null) {
      toast('Re-linked ${book.title}');
    } else {
      try {
        await scanner.ingestFile(File(path));
        toast('File added to the library');
      } catch (_) {
        toast('That file could not be read');
      }
    }
    notifyListeners();
  }

  void removeFromLibrary(Book book) {
    db.deleteBook(book.bookId);
    toast('Removed ${book.title} from this device (progress kept on Drive)');
    notifyListeners();
  }

  Future<void> deleteBookmark(Book markBook, String id) async {
    local.deleteBookmark(markBook, id);
    notifyListeners();
  }

  Future<Bookmark> addBookmark(Book book, String label) async {
    final bookmark = local.addBookmark(book, player.position, label);
    unawaited(sync.pushBook(book));
    notifyListeners();
    return bookmark;
  }

  // -------------------------------------------------------------- account

  Future<bool> signIn() async {
    final ok = await auth.signIn();
    if (ok) {
      local.signedOutOnPurpose = false;
      unawaited(sync.syncNow());
    } else if (auth.lastError != null) {
      toast(auth.lastError!);
    }
    notifyListeners();
    return ok;
  }

  Future<void> signOut() async {
    local.signedOutOnPurpose = true;
    await auth.signOut();
    toast('Signed out — progress keeps saving on this device');
    notifyListeners();
  }

  Future<void> forceSync() async {
    await sync.syncNow();
    toast(sync.lastSync == null
        ? 'Sync unavailable'
        : 'Synced ${relativeTime(sync.lastSync!)}');
    notifyListeners();
  }

  // ------------------------------------------------------------- settings

  void setThemeMode(ThemeMode mode) {
    theme.setMode(mode);
    local.themeMode = switch (mode) {
      ThemeMode.light => 'light',
      ThemeMode.dark => 'dark',
      ThemeMode.system => 'system',
    };
    notifyListeners();
  }

  void setDynamicColor(bool enabled) {
    theme.setDynamicColor(enabled);
    local.dynamicColor = enabled;
    notifyListeners();
  }

  void setSkipForward(int seconds) {
    local.skipForwardSeconds = seconds;
    notifyListeners();
  }

  void setSkipBackward(int seconds) {
    local.skipBackwardSeconds = seconds;
    notifyListeners();
  }

  void setSkipSilence(bool enabled) {
    local.skipSilence = enabled;
    unawaited(player.refreshSkipSilence());
    notifyListeners();
  }

  void setResumeBehavior(String value) {
    local.resumeBehavior = value;
    notifyListeners();
  }

  Future<void> clearCache() async {
    await local.clearCoverCache(); // also resets the "already checked" flags
    toast('Cover cache cleared — covers will be rebuilt');
    if (books.isNotEmpty) unawaited(_resolveMissingCovers(books));
    notifyListeners();
  }

  Future<void> shutdown() async {
    await player.saveAndPush(awaitPush: true);
    await watcher.dispose();
  }

  @override
  void dispose() {
    sync.removeListener(notifyListeners);
    _messages.close();
    super.dispose();
  }
}

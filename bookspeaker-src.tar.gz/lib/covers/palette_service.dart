/// Extracts a colour palette from cover art and turns it into the app's
/// dynamic theme, with a hard contrast guard so text always stays readable.
library;

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:palette_generator/palette_generator.dart';

class BookPalette {
  final Color vibrant;
  final Color dominant;
  final Color darkMuted;
  final Color lightMuted;
  final bool dimmed; // true when we had to fall back for readability

  const BookPalette({
    required this.vibrant,
    required this.dominant,
    required this.darkMuted,
    required this.lightMuted,
    this.dimmed = false,
  });

  static const fallback = BookPalette(
    vibrant: Color(0xFF4A3580), // Bookspeaker deep purple
    dominant: Color(0xFF4A3580),
    darkMuted: Color(0xFF241B3C),
    lightMuted: Color(0xFFEFEAF9),
  );

  Color get gold => const Color(0xFFC4A35A);
}

class PaletteService {
  static final Map<String, BookPalette> _cache = {};

  /// Palette for [imagePath], falling back to the brand palette when the file
  /// is missing or too plain.
  static Future<BookPalette> paletteFor(String? imagePath) async {
    if (imagePath == null || imagePath.isEmpty) return BookPalette.fallback;
    final cached = _cache[imagePath];
    if (cached != null) return cached;
    if (!File(imagePath).existsSync()) return BookPalette.fallback;
    try {
      final provider = FileImage(File(imagePath));
      final generator = await PaletteGenerator.fromImageProvider(
        provider,
        size: const Size(120, 120),
        maximumColorCount: 12,
      );
      final palette = _map(generator);
      _cache[imagePath] = palette;
      return palette;
    } catch (_) {
      return BookPalette.fallback;
    }
  }

  static BookPalette _map(PaletteGenerator g) {
    final vibrant = g.vibrantColor?.color ??
        g.lightVibrantColor?.color ??
        g.dominantColor?.color ??
        BookPalette.fallback.vibrant;
    final dominant = g.dominantColor?.color ?? vibrant;
    var darkMuted = g.darkMutedColor?.color ?? _darken(vibrant, 0.62);
    var lightMuted = g.lightMutedColor?.color ?? _lighten(vibrant, 0.92);

    var dimmed = false;
    // Keep the seeded background dark enough for #F5F5F5 text (dark mode) and
    // light enough for #1A1A1A text (light mode).
    if (_contrast(darkMuted, const Color(0xFFF5F5F5)) < 4.5) {
      darkMuted = _darken(darkMuted, 0.75);
      dimmed = true;
    }
    if (_contrast(lightMuted, const Color(0xFF1A1A1A)) < 4.5) {
      lightMuted = _lighten(lightMuted, 0.94);
      dimmed = true;
    }

    return BookPalette(
      vibrant: vibrant,
      dominant: dominant,
      darkMuted: darkMuted,
      lightMuted: lightMuted,
      dimmed: dimmed,
    );
  }

  static Color _darken(Color c, double amount) =>
      Color.lerp(c, Colors.black, amount) ?? c;

  static Color _lighten(Color c, double amount) =>
      Color.lerp(c, Colors.white, amount) ?? c;

  /// WCAG relative luminance contrast ratio.
  static double _contrast(Color a, Color b) {
    final la = _luminance(a);
    final lb = _luminance(b);
    final hi = la > lb ? la : lb;
    final lo = la > lb ? lb : la;
    return (hi + 0.05) / (lo + 0.05);
  }

  static double _luminance(Color c) {
    double channel(double v) {
      final s = v;
      return s <= 0.03928 ? s / 12.92 : _pow((s + 0.055) / 1.055);
    }

    return 0.2126 * channel(c.red / 255) +
        0.7152 * channel(c.green / 255) +
        0.0722 * channel(c.blue / 255);
  }

  static double _pow(double x) {
    // 2.4 gamma approximation good enough for contrast math.
    var result = 1.0;
    var base = x;
    var exp = 2.4;
    while (exp >= 1) {
      result *= base;
      exp -= 1;
    }
    final frac = exp;
    if (frac > 0) {
      result *= 1 + (base - 1) * frac;
    }
    return result;
  }

  /// Deterministic placeholder colour derived from the book title.
  static Color placeholderColor(String seed) {
    if (seed.isEmpty) return BookPalette.fallback.dominant;
    var hash = 0;
    for (final unit in seed.codeUnits) {
      hash = (hash * 31 + unit) & 0x7FFFFFFF;
    }
    final hue = (hash % 360).toDouble();
    return HSLColor.fromAHSL(1, hue, 0.32, 0.42).toColor();
  }

  static void clearCache() => _cache.clear();
}

/// Cover art resolution + caching.
///
/// Fallback chain, in order:
///   1. artwork embedded in the audio file
///   2. an image file in the same folder (cover.jpg / folder.png / …)
///   3. an online lookup — OpenLibrary, then Google Books, then iTunes —
///      shown to the user as a preview sheet or a suggestion card
///   4. generated placeholder (handled in the UI layer)
///
/// Two details matter for correctness:
///   * **Every write gets a fresh filename** (`<bookId>_<stamp>.jpg`). Writing
///     new bytes over the same path made Flutter's image cache keep serving the
///     old picture, which is why a replacement cover appeared not to apply.
///   * **Old files are pruned and evicted** from the image cache, so the new
///     artwork is visible immediately everywhere (grid, player, notification).
///
/// Slow work (tag reads, ID3 embedding) runs on worker isolates so the UI never
/// freezes.
library;

import 'dart:io';
import 'dart:isolate';
import 'dart:typed_data';

import 'package:flutter/painting.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;

import '../data/db.dart';
import '../library/book_model.dart';
import 'cover_sources/embedded_source.dart';
import 'cover_sources/folder_source.dart';
import 'cover_sources/image_validation.dart';
import 'cover_sources/openlibrary_source.dart';
import 'id3_cover_writer.dart';

class CoverArtService {
  CoverArtService(this.db, this.cacheDirectory);

  final BookspeakerDb db;
  final String cacheDirectory;
  final http.Client _client = http.Client();

  /// Why the last online lookup came back empty (shown in the UI).
  String? lastSearchNote;

  // --------------------------------------------------------------- caching

  /// Writes [bytes] as the book's artwork and points the database at the new
  /// file. Returns the path, or null when the payload is not a usable image.
  Future<String?> cacheCover(Book book, List<int> bytes) async {
    if (!CoverImage.isValidCover(bytes) && !CoverImage.looksLikeImage(bytes)) {
      return null;
    }
    final ext = CoverImage.isPng(bytes) ? 'png' : 'jpg';
    final stamp = DateTime.now().microsecondsSinceEpoch;
    final path = p.join(cacheDirectory, '${book.bookId}_$stamp.$ext');

    final dir = Directory(cacheDirectory);
    if (!dir.existsSync()) dir.createSync(recursive: true);
    await File(path).writeAsBytes(bytes, flush: true);

    await _pruneOldCovers(book.bookId, keep: path);
    db.setCoverPath(book.bookId, path);
    return path;
  }

  /// Deletes previously cached artwork for this book and drops it from
  /// Flutter's image cache so no stale picture can survive.
  Future<void> _pruneOldCovers(String bookId, {required String keep}) async {
    final dir = Directory(cacheDirectory);
    if (!dir.existsSync()) return;
    for (final entity in dir.listSync()) {
      if (entity is! File) continue;
      final name = p.basename(entity.path);
      if (!name.startsWith(bookId)) continue;
      if (p.equals(entity.path, keep)) continue;
      await evictFromImageCache(entity.path);
      try {
        entity.deleteSync();
      } catch (_) {}
    }
  }

  /// Removes a path from Flutter's in-memory image cache.
  static Future<void> evictFromImageCache(String path) async {
    try {
      await PaintingBinding.instance.imageCache.evict(FileImage(File(path)));
    } catch (_) {}
  }

  /// Reads the embedded picture in a background isolate (only a path string
  /// goes in, only plain bytes come back).
  static Future<({Uint8List bytes, String mime})?> extractEmbedded(String path) =>
      Isolate.run(() => EmbeddedCoverSource.extract(path));

  /// Steps 1 + 2 of the chain: artwork that already exists on this device.
  Future<String?> resolveLocalCover(Book book) async {
    // Whatever the database already points at wins (this is what the user
    // chose, including manual overrides) — as long as it still exists.
    final cached = book.coverCachePath;
    if (cached != null && File(cached).existsSync()) return cached;

    if (!File(book.filePath).existsSync()) return null;

    // 1. embedded artwork
    final embedded = await extractEmbedded(book.filePath);
    if (embedded != null) {
      final ext = embedded.mime.contains('png') ? 'png' : 'jpg';
      final path = p.join(cacheDirectory, '${book.bookId}_embedded.$ext');
      await File(path).writeAsBytes(embedded.bytes, flush: true);
      db.setCoverPath(book.bookId, path);
      return path;
    }

    // 2. sibling image file
    final folderImage = FolderCoverSource.find(book.filePath);
    if (folderImage != null) {
      final ext = p.extension(folderImage.path).replaceFirst('.', '').toLowerCase();
      final path = p.join(cacheDirectory,
          '${book.bookId}_folder.${ext == "png" ? "png" : "jpg"}');
      await folderImage.copy(path);
      db.setCoverPath(book.bookId, path);
      return path;
    }

    // 3. artwork cached earlier but not linked in the database
    final existing = _anyCachedCover(book.bookId);
    if (existing != null) {
      db.setCoverPath(book.bookId, existing);
      return existing;
    }

    return null;
  }

  String? _anyCachedCover(String bookId) {
    final dir = Directory(cacheDirectory);
    if (!dir.existsSync()) return null;
    for (final entity in dir.listSync()) {
      if (entity is! File) continue;
      final name = p.basename(entity.path);
      if (!name.startsWith(bookId)) continue;
      final ext = p.extension(name).toLowerCase();
      if (ext == '.jpg' || ext == '.jpeg' || ext == '.png') return entity.path;
    }
    return null;
  }

  // ---------------------------------------------------------------- online

  /// Looks for artwork online. Never throws: an empty result comes back with a
  /// human-readable reason in [CoverSearchOutcome.note].
  Future<CoverSearchOutcome> findOnlineCover(Book book) async {
    lastSearchNote = null;

    final ol = await OpenLibrarySource.search(_client, book.title, book.author);
    if (ol.candidate != null) return ol;
    lastSearchNote = ol.note;

    final gb = await GoogleBooksSource.search(_client, book.title, book.author);
    if (gb.candidate != null) return gb;
    lastSearchNote = [lastSearchNote, gb.note]
        .whereType<String>()
        .where((s) => s.isNotEmpty)
        .join(' • ');

    final it = await ItunesSource.search(_client, book.title, book.author);
    if (it.candidate != null) return it;
    final notes = [lastSearchNote, it.note]
        .whereType<String>()
        .where((s) => s.isNotEmpty)
        .toList();
    lastSearchNote = notes.isEmpty ? 'No cover found online' : notes.join(' • ');

    return CoverSearchOutcome(null, lastSearchNote);
  }

  // ------------------------------------------------------------- embedding

  /// Writes the artwork into the audio file itself (MP3 / ID3v2 APIC frame).
  /// Runs on a worker isolate; returns false when the format or the file does
  /// not allow it.
  Future<bool> embedCover(Book book, List<int> bytes) async {
    if (book.format != AudioFormat.mp3) return false;
    if (!File(book.filePath).existsSync()) return false;
    final mime = CoverImage.isPng(bytes) ? 'image/png' : 'image/jpeg';
    try {
      return await Isolate.run(
          () => Id3CoverWriter.embed(book.filePath, bytes, mime: mime));
    } catch (_) {
      return false;
    }
  }

  /// Manual override ("Set Cover Art"): reads the picked image and applies it.
  /// Returns the new cache path, or null when the file cannot be read.
  Future<String?> setCoverFromBytes(Book book, List<int> bytes) =>
      cacheCover(book, bytes);

  Future<List<int>?> readImageFile(String path) async {
    final file = File(path);
    if (!file.existsSync()) return null;
    final bytes = await file.readAsBytes();
    return bytes.isEmpty ? null : bytes;
  }

  void dispose() => _client.close();
}

/// Cover art source #2 — an image file sitting next to the audio file.
library;

import 'dart:io';

import 'package:path/path.dart' as p;

class FolderCoverSource {
  static const candidates = [
    'cover.jpg',
    'cover.jpeg',
    'cover.png',
    'folder.jpg',
    'folder.jpeg',
    'folder.png',
    'front.jpg',
    'artwork.jpg',
  ];

  /// Returns the first matching image next to [audioFilePath], or null.
  static File? find(String audioFilePath) {
    final dir = Directory(p.dirname(audioFilePath));
    if (!dir.existsSync()) return null;

    for (final name in candidates) {
      final f = File(p.join(dir.path, name));
      if (f.existsSync()) return f;
    }
    // Case-insensitive sweep as a fallback.
    try {
      for (final entry in dir.listSync()) {
        if (entry is! File) continue;
        final base = p.basename(entry.path).toLowerCase();
        if (candidates.contains(base)) return entry;
      }
    } catch (_) {}
    return null;
  }
}

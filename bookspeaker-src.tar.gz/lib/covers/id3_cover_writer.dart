/// Writes cover art back into MP3 files (ID3v2 APIC frame) so the artwork
/// travels with the file and every other player shows it.
///
/// The existing ID3v2 tag is rebuilt (not stacked): text frames are preserved,
/// the previous picture frames are replaced, and the raw audio payload is
/// copied through untouched — which keeps the audio fingerprint stable.
library;

import 'dart:io';
import 'dart:typed_data';

class Id3CoverWriter {
  static const _preservedFrames = {
    'TIT2', // title
    'TPE1', // lead performer
    'TPE2', // band/orchestra
    'TALB', // album
    'TRCK', // track
    'TCON', // genre
    'TYER', // year (v2.3)
    'TDRC', // recording time (v2.4)
    'COMM', // comments
    'TLAN', // language
  };

  /// Embeds [imageBytes] as the front cover of the MP3 at [filePath].
  /// Returns true when the file was rewritten.
  static Future<bool> embed(
    String filePath,
    List<int> imageBytes, {
    String mime = 'image/jpeg',
  }) async {
    final file = File(filePath);
    if (!file.existsSync()) return false;
    final total = await file.length();

    final raf = await file.open();
    try {
      final header = Uint8List.fromList(await raf.read(10));
      var audioStart = 0;
      var existingTagSize = 0;

      final hasId3v2 = header.length >= 10 &&
          header[0] == 0x49 &&
          header[1] == 0x44 &&
          header[2] == 0x33;
      if (hasId3v2) {
        existingTagSize = 10 +
            (((header[6] & 0x7F) << 21) |
                ((header[7] & 0x7F) << 14) |
                ((header[8] & 0x7F) << 7) |
                (header[9] & 0x7F)) +
            ((header[5] & 0x10) != 0 ? 10 : 0);
        audioStart = existingTagSize;
      }

      // Preserve readable text frames from the existing tag.
      final keptFrames = <Uint8List>[];
      if (hasId3v2 && existingTagSize > 10) {
        await raf.setPosition(10);
        final tagBytes =
            Uint8List.fromList(await raf.read(existingTagSize - 10));
        keptFrames.addAll(_parseTextFrames(tagBytes, header[3]));
      }

      final tag = _buildTag(keptFrames, imageBytes, mime);
      final tmp = File('$filePath.bsbak');
      final out = await tmp.open(mode: FileMode.writeOnly);

      try {
        await out.writeFrom(tag);
        // copy the audio payload in 4 MB chunks
        var pos = audioStart;
        const chunk = 4 * 1024 * 1024;
        while (pos < total) {
          final len = (total - pos) < chunk ? (total - pos) : chunk;
          await raf.setPosition(pos);
          final data = await raf.read(len);
          if (data.isEmpty) break;
          await out.writeFrom(data);
          pos += data.length;
        }
      } finally {
        await out.close();
        await raf.close();
      }

      // Swap in the rewritten file.
      final backup = File('$filePath.orig');
      if (backup.existsSync()) backup.deleteSync();
      file.renameSync(backup.path);
      tmp.renameSync(filePath);
      backup.deleteSync();
      return true;
    } catch (_) {
      try {
        await raf.close();
      } catch (_) {}
      return false;
    }
  }

  static List<Uint8List> _parseTextFrames(Uint8List tag, int version) {
    final frames = <Uint8List>[];
    var offset = 0;
    final v4 = version == 4;
    while (offset + 10 <= tag.length) {
      final id = String.fromCharCodes(tag.sublist(offset, offset + 4));
      if (id.trim().isEmpty || !RegExp(r'^[A-Z0-9]{4}$').hasMatch(id)) break;
      final rawSize = _readUInt32(tag, offset + 4);
      final size = v4
          ? (((rawSize >> 24) & 0x7F) << 21) |
              (((rawSize >> 16) & 0x7F) << 14) |
              (((rawSize >> 8) & 0x7F) << 7) |
              (rawSize & 0x7F)
          : rawSize;
      if (size <= 0 || offset + 10 + size > tag.length) break;
      if (_preservedFrames.contains(id)) {
        final body = tag.sublist(offset + 10, offset + 10 + size);
        frames.add(_frame(id, body));
      }
      offset += 10 + size;
    }
    return frames;
  }

  static Uint8List _buildTag(
    List<Uint8List> textFrames,
    List<int> imageBytes,
    String mime,
  ) {
    final apic = BytesBuilder();
    apic.addByte(0x00); // ISO-8859-1 encoding for the description field
    apic.add(_latin1('$mime\u0000'));
    apic.addByte(0x03); // picture type: front cover
    apic.add(_latin1('Cover\u0000'));
    apic.add(imageBytes);

    final frames = <Uint8List>[
      ...textFrames,
      _frame('APIC', apic.takeBytes()),
    ];

    final body = BytesBuilder();
    for (final f in frames) {
      body.add(f);
    }
    final padding = Uint8List(1024); // room for future tag edits

    final bodyBytes = body.takeBytes();
    final out = BytesBuilder();
    out.add([0x49, 0x44, 0x33, 0x03, 0x00, 0x00]); // ID3 v2.3.0, no flags
    out.add(_syncSafe(bodyBytes.length + padding.length));
    out.add(bodyBytes);
    out.add(padding);
    return out.takeBytes();
  }

  static Uint8List _frame(String id, List<int> body) {
    final b = BytesBuilder();
    b.add(_latin1(id));
    b.add(_uint32(body.length));
    b.add([0x00, 0x00]); // frame flags
    b.add(body);
    return b.takeBytes();
  }

  static List<int> _latin1(String s) =>
      s.codeUnits.map((c) => c > 0xFF ? 0x3F : c).toList();

  static Uint8List _uint32(int value) => Uint8List.fromList([
        (value >> 24) & 0xFF,
        (value >> 16) & 0xFF,
        (value >> 8) & 0xFF,
        value & 0xFF,
      ]);

  static Uint8List _syncSafe(int value) => Uint8List.fromList([
        (value >> 21) & 0x7F,
        (value >> 14) & 0x7F,
        (value >> 7) & 0x7F,
        value & 0x7F,
      ]);

  static int _readUInt32(Uint8List b, int offset) =>
      (b[offset] << 24) | (b[offset + 1] << 16) | (b[offset + 2] << 8) | b[offset + 3];
}

/// Convenience wrapper used by the cover service.
Future<bool> embedCoverInMp3(String path, List<int> bytes, {String mime = 'image/jpeg'}) =>
    Id3CoverWriter.embed(path, bytes, mime: mime);

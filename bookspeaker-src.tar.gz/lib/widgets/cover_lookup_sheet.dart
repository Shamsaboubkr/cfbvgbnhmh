/// "Cover art" sheet: shows what was found online (or why nothing was found)
/// and lets the user apply it.
///
/// Failures used to be completely silent — the request ran, found nothing, and
/// the user saw an empty screen. This sheet always reports a result: a
/// preview + *Use this cover*, or a reason plus *Try again*.
library;

import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../app_state.dart';
import '../covers/cover_sources/openlibrary_source.dart';
import '../library/book_model.dart';

Future<void> showCoverLookupSheet(
  BuildContext context,
  AppState state,
  Book book,
) {
  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (_) => _CoverLookupSheet(state: state, book: book),
  );
}

/// Shows a preview for an image the user picked themselves (or one that was
/// already found), with the same confirm step.
Future<void> showCoverPreviewSheet(
  BuildContext context,
  AppState state,
  Book book,
  CoverCandidate candidate,
) {
  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (_) => _CoverLookupSheet(
      state: state,
      book: book,
      initialCandidate: candidate,
      autoSearch: false,
    ),
  );
}

class _CoverLookupSheet extends StatefulWidget {
  const _CoverLookupSheet({
    required this.state,
    required this.book,
    this.initialCandidate,
    this.autoSearch = true,
  });

  final AppState state;
  final Book book;
  final CoverCandidate? initialCandidate;
  final bool autoSearch;

  @override
  State<_CoverLookupSheet> createState() => _CoverLookupSheetState();
}

class _CoverLookupSheetState extends State<_CoverLookupSheet> {
  bool _searching = false;
  CoverCandidate? _candidate;
  String? _note;

  @override
  void initState() {
    super.initState();
    _candidate = widget.initialCandidate;
    if (widget.autoSearch) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _search());
    }
  }

  Future<void> _search() async {
    setState(() {
      _searching = true;
      _note = null;
      _candidate = null;
    });
    final outcome = await widget.state.findCover(widget.book);
    if (!mounted) return;
    setState(() {
      _searching = false;
      _candidate = outcome.candidate;
      _note = outcome.note;
    });
  }

  Future<void> _apply() async {
    final candidate = _candidate;
    if (candidate == null) return;
    Navigator.of(context).pop();
    await widget.state.applyCoverBytes(
      widget.book,
      candidate.bytes ?? const <int>[],
      source: candidate.source,
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 0, 24, 28),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Cover art', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 2),
          Text(
            '${widget.book.title}'
            '${widget.book.author.isEmpty ? '' : ' — ${widget.book.author}'}',
            style: theme.textTheme.bodySmall,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 16),
          if (_searching) ...[
            const Center(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 28),
                child: CircularProgressIndicator(),
              ),
            ),
            Center(
              child: Text('Searching OpenLibrary, Google Books and iTunes…',
                  style: theme.textTheme.bodySmall),
            ),
          ] else if (_candidate != null) ...[
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SizedBox(
                  width: 180,
                  height: 240,
                  child: Image.memory(
                    Uint8List.fromList(_candidate!.bytes ?? const <int>[]),
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const ColoredBox(
                      color: Color(0x224A3580),
                      child: Center(child: Icon(Icons.image_not_supported)),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Center(
              child: Text('Found on ${_candidate!.source}',
                  style: theme.textTheme.bodySmall),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: _apply,
                    icon: const Icon(Icons.check),
                    label: const Text('Use this cover'),
                  ),
                ),
                const SizedBox(width: 10),
                OutlinedButton(
                  onPressed: _search,
                  child: const Text('Search again'),
                ),
              ],
            ),
          ] else ...[
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: theme.colorScheme.surfaceContainerHighest.withOpacity(0.4),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.search_off, size: 18),
                      SizedBox(width: 8),
                      Text('No cover found online',
                          style: TextStyle(fontWeight: FontWeight.w700)),
                    ],
                  ),
                  if (_note != null) ...[
                    const SizedBox(height: 6),
                    Text(_note!, style: theme.textTheme.bodySmall),
                  ],
                  const SizedBox(height: 6),
                  Text(
                    'You can also set your own image: long-press the book → '
                    'Set Cover Art.',
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: FilledButton.tonalIcon(
                    onPressed: _search,
                    icon: const Icon(Icons.refresh),
                    label: const Text('Try again'),
                  ),
                ),
                const SizedBox(width: 10),
                OutlinedButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Close'),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

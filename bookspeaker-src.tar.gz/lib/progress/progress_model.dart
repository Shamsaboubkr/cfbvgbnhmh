/// Progress-related models.
///
/// The canonical definitions live in `library/book_model.dart` (shared by the
/// library and the player); this file exposes them on the progress layer so the
/// project layout matches the specification.
library;

export '../library/book_model.dart'
    show
        BookProgress,
        Bookmark,
        DeviceHistoryEntry,
        SyncStatus,
        SyncStatusX,
        formatDuration,
        relativeTime;

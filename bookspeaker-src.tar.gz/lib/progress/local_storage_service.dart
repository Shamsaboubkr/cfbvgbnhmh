/// Local persistence for progress + settings (SQLite, always written first).
library;

import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import '../data/db.dart';
import '../library/book_model.dart';

class LocalStorageService {
  LocalStorageService._(this.db, this.supportDirectory, this.cacheDirectory);

  final BookspeakerDb db;
  final String supportDirectory;
  final String cacheDirectory;

  static const _uuid = Uuid();

  /// Builds an instance over an explicit directory — used by tests, which have
  /// no `path_provider` platform channel available.
  @visibleForTesting
  static LocalStorageService forTesting(String directory) {
    final coverCache = p.join(directory, 'cover_cache');
    if (!Directory(coverCache).existsSync()) {
      Directory(coverCache).createSync(recursive: true);
    }
    final db = BookspeakerDb.open(p.join(directory, 'bookspeaker.db'))
      ..coverCacheDir = coverCache
      ..dbPath = p.join(directory, 'bookspeaker.db');
    return LocalStorageService._(db, directory, coverCache);
  }

  static Future<LocalStorageService> open() async {
    final support = await getApplicationSupportDirectory();
    final dir = support.path;
    final coverCache = p.join(dir, 'cover_cache');
    if (!Directory(coverCache).existsSync()) {
      Directory(coverCache).createSync(recursive: true);
    }
    final db = BookspeakerDb.open(p.join(dir, 'bookspeaker.db'));
    db
      ..coverCacheDir = coverCache
      ..dbPath = p.join(dir, 'bookspeaker.db');
    return LocalStorageService._(db, dir, coverCache);
  }

  // -------------------------------------------------------------- settings

  int get skipForwardSeconds => db.getIntSetting('skip_forward', 15);
  set skipForwardSeconds(int v) => db.setSetting('skip_forward', '$v');

  int get skipBackwardSeconds => db.getIntSetting('skip_back', 15);
  set skipBackwardSeconds(int v) => db.setSetting('skip_back', '$v');

  /// "auto" (silently adopt the newest position) or "ask" (show the picker).
  String get resumeBehavior => db.getSetting('resume_behavior') ?? 'ask';
  set resumeBehavior(String v) => db.setSetting('resume_behavior', v);

  String get themeMode => db.getSetting('theme_mode') ?? 'system';
  set themeMode(String v) => db.setSetting('theme_mode', v);

  bool get dynamicColor => db.getBoolSetting('dynamic_color', true);
  set dynamicColor(bool v) => db.setSetting('dynamic_color', v ? 'true' : 'false');

  /// Silence skipping is opt-in; off unless the user turns it on.
  bool get skipSilence => db.getBoolSetting('skip_silence', false);
  set skipSilence(bool v) => db.setSetting('skip_silence', v ? 'true' : 'false');

  bool get onboardingDone => db.getBoolSetting('onboarding_done', false);
  set onboardingDone(bool v) =>
      db.setSetting('onboarding_done', v ? 'true' : 'false');

  bool get signedOutOnPurpose => db.getBoolSetting('signed_out', false);
  set signedOutOnPurpose(bool v) =>
      db.setSetting('signed_out', v ? 'true' : 'false');

  String? get lastSyncedAt => db.getSetting('last_synced_at');
  set lastSyncedAt(String? v) => db.setSetting('last_synced_at', v ?? '');

  String get deviceName => db.deviceName;
  set deviceName(String v) => db.deviceName = v;

  String get deviceType => db.deviceType;

  // ------------------------------------------------------------- progress

  double speedFor(String bookId) =>
      db.progressFor(bookId)?.playbackSpeed ?? 1.0;

  /// Saves progress locally and marks it pending for Drive.
  void saveProgress(
    Book book, {
    required Duration position,
    required Duration total,
    double? speed,
    bool? finished,
    bool queueForSync = true,
  }) {
    final existing = db.ensureProgress(book);
    final totalMs = total.inMilliseconds > 0
        ? total.inMilliseconds
        : (book.totalDuration.inMilliseconds > 0
            ? book.totalDuration.inMilliseconds
            : existing.totalDuration_ms);
    final posMs = position.inMilliseconds.clamp(0, totalMs > 0 ? totalMs : 1 << 62);
    final pct = totalMs > 0 ? (posMs / totalMs) * 100.0 : 0.0;

    final progress = BookProgress(
      bookId: book.bookId,
      position_ms: posMs,
      totalDuration_ms: totalMs,
      percentComplete: double.parse(pct.toStringAsFixed(2)),
      playbackSpeed: speed ?? existing.playbackSpeed,
      finished: finished ?? (totalMs > 0 && pct >= 99.5),
      lastPlayed: DateTime.now(),
      lastPlayedDevice: db.deviceName,
      deviceType: db.deviceType,
      bookmarks: existing.bookmarks,
      syncStatus: queueForSync ? SyncStatus.pending : existing.syncStatus,
      deviceHistory: db.historyFor(book.bookId),
    );
    db.saveProgress(progress);
  }

  /// Records the position in the per-device history used by the conflict picker.
  void recordDeviceHistory(Book book, Duration position) {
    final device = db.deviceName;
    final existing = db.historyFor(book.bookId);
    final same = existing.where(
      (e) => e.deviceName == device && e.deviceType == db.deviceType,
    );
    final id = same.isNotEmpty
        ? '${book.bookId}_${device.hashCode.toRadixString(16)}'
        : _uuid.v4();
    db.addHistoryEntry(
      book.bookId,
      DeviceHistoryEntry(
        deviceName: device,
        deviceType: db.deviceType,
        position_ms: position.inMilliseconds,
        timestamp: DateTime.now(),
      ),
      id,
    );
  }

  // ------------------------------------------------------------ bookmarks

  Bookmark addBookmark(Book book, Duration position, String label) {
    final bm = Bookmark(
      id: 'bm_${_uuid.v4().substring(0, 8)}',
      position_ms: position.inMilliseconds,
      label: label,
      created: DateTime.now(),
    );
    db.addBookmark(book.bookId, bm);
    final progress = db.progressFor(book.bookId);
    if (progress != null) {
      progress.bookmarks = db.bookmarksFor(book.bookId);
      progress.syncStatus = SyncStatus.pending;
      db.saveProgress(progress);
    }
    return bm;
  }

  void deleteBookmark(Book book, String id) {
    db.deleteBookmark(id);
    final progress = db.progressFor(book.bookId);
    if (progress != null) {
      progress.syncStatus = SyncStatus.pending;
      db.saveProgress(progress);
    }
  }

  List<(Bookmark, String, String)> allBookmarks() => db.allBookmarksWithBook();

  // --------------------------------------------------------------- cleanup

  Future<void> clearCoverCache() async {
    final dir = Directory(cacheDirectory);
    if (dir.existsSync()) {
      for (final f in dir.listSync()) {
        if (f is File) f.deleteSync();
      }
    }
    db.resetCoverChecks();
  }

  int get cacheBytes {
    final dir = Directory(cacheDirectory);
    if (!dir.existsSync()) return 0;
    return dir
        .listSync(recursive: true)
        .whereType<File>()
        .fold<int>(0, (sum, f) => sum + f.lengthSync());
  }

  void close() => db.close();
}

# Why sync kept failing — "Client is already closed"

**Reported:** every entry in the log says *offline — retrying in 45 s* while the phone shows 4G,
and the error line reads:

```
ClientException: HTTP request failed. Client is already closed.,
uri=https://www.googleapis.com/drive/v3/files?q=name%20%3D%20%27650f1cf00c145b31_progress.json%27…
```

**Verdict: a bug in this app, not the network, and not your Google account.** The misleading
"offline" wording was a second bug of mine.

---

## The bug

`lib/progress/drive_sync_service.dart` held **one** HTTP client for the entire app run:

```dart
final http.Client _http = http.Client();          // created once, at startup
```

Every Drive session wrapped that same client, and every call closed the session when it
finished:

```dart
_BearerClient(_http, token);                      // session wraps the shared client

@override
void close() => _inner.close();                   // …closing the shared client

} finally {
  session?.client.close();                        // runs after EVERY sync
}
```

So the sequence was:

1. First Drive call after launch (the pull on app open) — works.
2. Its `finally` block closes the shared client.
3. **Every** later request — the 30 s pushes, pause pushes, bookmark pushes, full syncs —
   throws `Client is already closed`.

That is exactly why sync only ever appeared to work in the first moments after a restart:
the first operation of each launch succeeded and everything afterwards failed. My earlier
`saveAndPush(push: false)` finding was a second, smaller bug stacked on this one — the close
paths never asked for a push. With this bug, even when they had asked, the push would have
died.

## Why it said "offline" on 4G

```dart
SyncState _classify(Object error) {
  if (error is commons.DetailedApiRequestError) { … }
  return SyncState.offline;      // ← everything else was blamed on the network
}
```

`ClientException` isn't an API error, so it fell through to `offline` — hence "Offline —
progress saved locally" in the banner, the orange cloud icons, and a 45 s retry loop that
could never succeed. A programming error was being reported to you as a connection problem.

## The fixes

1. **A client per session.** `_session()` now builds a short-lived client
   (`buildSession(token, factory)`, factory injectable for tests), so closing one session can
   never affect another. The shared field is gone; `dispose()` no longer closes anything
   shared.
2. **Honest classification.** `classifyError` distinguishes:
   * `ClientException` containing `already closed` → **error** (a bug), not offline;
   * other `ClientException` / `SocketException` / `TimeoutException` → **offline**;
   * `DetailedApiRequestError` 401/403 → sign-in expired, 403 quota → Drive full,
     429/5xx → offline;
   * anything else → **error** — no longer disguised as a network problem.
3. **Retry only when retrying can help.** The 45 s retry is scheduled for `offline` only;
   a bug no longer spins a pointless retry loop.
4. **Repeated failures collapse.** The log merges identical consecutive failures into one row
   with a ×N count, so a retry loop cannot bury the interesting entries.
5. **The raw exception moved out of the way.** Settings shows one short line
   (`sync failed — HTTP request failed. Client is already closed.`) instead of a wall of red
   text; the full message stays in the log row.

## Tests — `test/sync_client_test.dart`

| Test | Asserts |
|---|---|
| each session gets its own client | two sessions → two distinct clients; closing the first leaves the second unclosed **and usable** (this test fails on the old code) |
| closed-client error is a bug, not offline | `classifyError(ClientException('…already closed…')) == SyncState.error` |
| real connection failures are offline | `ClientException('Connection closed before full header…')`, `SocketException`, `TimeoutException` → `SyncState.offline` |
| unknown failures stay unknown | `StateError`, `ArgumentError` → `SyncState.error` |

## Answering "the old one was even better"

It looked better because it failed **silently**. The old build had this same bug — every
launch synced once and then quietly stopped — it just showed a calm "Offline, progress saved
locally" and never mentioned it. The new build did the one thing the old one never did: it
told you the truth, which is how this bug got found and fixed. The sync log is the reason we
are looking at the real cause instead of guessing.

## What to expect after v1.0.4

Play for a minute with the screen on, then open **Settings → Account**:

* **Playback save cadence** — `Local every 10s — last 4s ago` / `Drive every 30s — last 21s ago`
* **Sync activity** — entries reading `pushed to Drive` every 30 seconds, newest first
* Top bar chip — `Syncing…` briefly every 30 s, then `Synced 3s ago`, counting up

If entries instead say `sign-in expired` or `sync failed — … 403`, the app is now working
correctly and the remaining problem is the Google Cloud Console setup
(`ANDROID_DRIVE_SETUP.md`). The wording tells you which side to fix.

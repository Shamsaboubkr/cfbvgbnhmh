# Sync investigation — is Drive syncing during playback?

**Short answer: yes, the 30-second timer was already there and already firing** — but **four
other parts of the spec were genuinely broken, and two of them are exactly why it *looked*
like sync only happened on restart.** Everything below was verified by running the real
`AudioPlayerService` against a recording sync layer (`test/sync_cadence_test.dart`), not by
reading the code and assuming.

---

## 1. The evidence: the timer code

`lib/player/audio_player_service.dart` — the cadence that runs while audio plays:

```dart
// line 172
Future<void> play() async {
  if (_currentBook == null) return;
  if (_completed) { await player.seek(Duration.zero); _completed = false; }
  _startTimers();                 // ← started the moment playback starts
  await player.play();
  ...
}

// line 284
void _startTimers() {
  _localSaveTimer?.cancel();
  _drivePushTimer?.cancel();
  // Spec: local every 10 s, Drive every 30 s while playing.
  _localSaveTimer  = Timer.periodic(localSaveInterval,  (_) { _localSaveTick++;
      _lastLocalSaveAt = DateTime.now(); _saveLocal(); });   // 10 s
  _drivePushTimer  = Timer.periodic(drivePushInterval, (_) {  // 30 s
    final book = _currentBook;
    if (book == null) return;
    _drivePushTick++;
    _lastDrivePushAt = DateTime.now();
    unawaited(sync.pushBook(book));      // ← the actual Drive push
  });
}

// line 185
Future<void> pause() async {
  _stopTimers();                  // cadence stops
  _saveLocal();                   // local save is immediate
  final book = _currentBook;
  if (book != null) unawaited(sync.pushBook(book));   // ← immediate push on pause
  ...
}
```

`pushBook` (`lib/progress/drive_sync_service.dart:536`) then reads the freshest row from
SQLite and writes `<bookId>_progress.json` + `manifest.json` into the hidden Drive app folder.

## 2. Answers to the seven questions

| # | Question | Verdict | Where |
|---|---|---|---|
| 1 | Is a 30 s timer actually pushing to Drive? | **Yes, already was.** `Timer.periodic` → `sync.pushBook` | `audio_player_service.dart:293` |
| 2 | Is it started when playback begins? | **Yes** — `play()` calls `_startTimers()`; the notification / lock-screen / Bluetooth path routes through `BookspeakerAudioHandler.play() → service.play()`, so it starts there too | `:172`, `:409` |
| 3 | Is it cancelled when it shouldn't be? | **It leaked in two ways** — see bugs 1 and 2 below | `pause()`, lifecycle |
| 4 | Does pausing trigger an immediate push? | **Yes** — and now it happens *synchronously on the tap* | `:185` |
| 5 | Does switching books push? | **No — was broken.** Fixed | `:125-131` |
| 6 | Is "Syncing…" / "Synced X ago" visible every 30 s? | **Was invisible.** Fixed with a ticking chip | `sync_indicator.dart` |
| 7 | Settings → "Last synced" updating live? | **Was frozen.** Fixed | `settings_screen.dart` |

## 3. The four real bugs found

### Bug 1 — "Push on app close" never pushed  *(this is the big one)*
`saveAndPush()` was declared `{bool push = false}` and **every** close path called it without
arguments:

```dart
// root Back button — lib/app/bookspeaker_app.dart:154
await state.player.saveAndPush();     // push: false → local save only
// shutdown() — lib/app_state.dart:637  → same
```

So closing the app saved to SQLite and **never talked to Drive**. Combine that with the fact
that there was **no app-lifecycle handling anywhere** (`WidgetsBindingObserver` appeared
nowhere in `lib/`), and the observable behaviour was: *sync only seems to happen when the app
restarts* — exactly the report.

**Fix:** `push` now defaults to `true`; the close paths use
`saveAndPush(awaitPush: true)`, which awaits the push (bounded to 6 s) so the process cannot
die with the push still in flight. Plus a new lifecycle observer flushes on
`paused` / `hidden` / `detached` (Home button, screen off, task swiped away) and pulls on
`resumed`:

```dart
// lib/app/bookspeaker_app.dart:110
void didChangeAppLifecycleState(AppLifecycleState state) {
  final app = context.read<AppState>();
  switch (state) {
    case AppLifecycleState.paused:
    case AppLifecycleState.hidden:
    case AppLifecycleState.detached:
      unawaited(app.player.saveAndPush(awaitPush: true));
    case AppLifecycleState.resumed:
      if (app.sync.isSignedIn) unawaited(app.sync.syncNow());   // pull on app open
    case AppLifecycleState.inactive:
      break;
  }
}
```

### Bug 2 — Book switch saved locally but never pushed
`openBook()` called `_saveLocal()` for the book being left and moved on. The spec's
"push immediately on book switch" was not implemented:

```dart
// now, lib/player/audio_player_service.dart:125
final previous = _currentBook;
_saveLocal();
if (previous != null && previous.bookId != book.bookId) {
  unawaited(sync.pushBook(previous));    // ← added
}
```

### Bug 3 — A failed session could freeze the chip on "Syncing…" forever
In `syncNow()` and `pushBook()`, `if (session == null) return;` bailed out **after**
`_setState(SyncState.syncing)` — leaving the badge blue forever with no way to tell that
sync had died. Both paths now set an explicit terminal state (`signedOut`) and log the reason.

### Bug 4 — A failing platform pause could leave the cadence running
`pause()` awaited `player.pause()` *before* `_stopTimers()`. If that platform call threw
(audio focus loss, file removed mid-play) the timers kept ticking behind a paused player.
The order is now: stop the cadence → save → push → *then* talk to the player, with the
platform call guarded.

## 4. Visible proof added (your requests 6 and 7)

* **The chip now ticks.** `SyncIndicator` was a `StatelessWidget` that only rebuilt when the
  sync *state* changed, so "Synced just now" sat frozen — and `relativeTime()` collapses
  anything under 60 s into "just now", so the label literally could not change. It now
  re-renders once a second and reads `Synced 12s ago`, counting up, resetting to `just now`
  at every 30 s push. A push is also held on screen as **"Syncing…" for 900 ms** so it is
  perceivable instead of a sub-second flicker.
* **Settings → Account → "Playback save cadence"**: live counters straight off the player —
  `Local every 10s — last 3s ago` / `Drive every 30s — last 17s ago` — with a running
  total of how many ticks have fired. Watch them advance while listening.
* **Settings → Account → "Sync activity"**: the last pushes, newest first, each with
  wall-clock time, the book, the position pushed and the outcome:
  ```
  09:14:32 · The Great Gatsby · 2:32:07 · pushed to Drive
  09:14:02 · The Great Gatsby · 2:31:37 · pushed to Drive
  09:14:00 · Full sync · pulled 12 book(s) from Drive
  09:11:12 · Atomic Habits · 1:04:55 · offline — retrying in 45 s
  ```
  Newest first, in `lib/progress/drive_sync_service.dart` (`SyncActivity`, `_log`).

## 5. Proof it works — `test/sync_cadence_test.dart` (6 tests, all passing)

The tests drive the **production** `AudioPlayerService` with injected short intervals
(40 ms / 100 ms) and a recording sync service, so the assertions are about the real code path:

| Test | Asserts |
|---|---|
| playing starts a repeating Drive push cadence | ≥3 pushes in 360 ms at a 100 ms interval; the tick counter matches |
| playing saves locally on its own cadence | ≥4 local saves in 300 ms; the row exists in SQLite |
| pause stops the cadence and pushes once | exactly +1 push on the pause call, none afterwards |
| switching books pushes the book being left | the push list is `['old']` after opening `'new'` |
| app close saves and pushes | +1 push, not local-only |
| does nothing with no book loaded | zero pushes, cadence off |

Full suite: **27/27 passing**; `flutter analyze`: 14 issues, all style infos, 0 errors/warnings.

## 6. One thing this cannot prove from here

The tests prove the cadence fires and hands every push to the sync layer. Whether those
pushes *land in your Drive* depends on the Console settings (Drive API enabled, the Android
OAuth client for `com.bookspeaker.app` + SHA-1 `06:8A:6A:…:92:87`, your Gmail added as a
test user) — see `ANDROID_DRIVE_SETUP.md`. The new "Sync activity" list is the fastest way to
tell the two apart: entries marked `pushed to Drive` mean the network side worked;
`offline — retrying` / `sign-in expired` / a 403 reason means the app is fine and the
Console is not.

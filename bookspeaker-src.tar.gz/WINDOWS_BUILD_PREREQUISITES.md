# Windows MSI — what's needed before the build

Two hard facts first, because they shape everything else:

1. **The MSI cannot be produced here.** This sandbox is Linux. Flutter's Windows desktop
   target needs a Windows host with Visual Studio's C++ toolchain, and an `.msi` needs WiX
   Toolset (Windows-only). So the *build* must run on your PC.
2. **The Windows source doesn't exist yet.** `windows/` is still the stock `flutter create`
   scaffold: a 1280×720 window, no MSIX/WiX config, no tray, no desktop sign-in. Nobody has
   written the Windows-only features from your spec.

So the work splits cleanly:

| Who | What |
|---|---|
| **Me, here** | Write all the Windows source + installer config + a one-command build script |
| **You, on Windows** | Install the toolchain (once), run the script, send me any error text |

---

## Which format? MSI vs EXE vs MSIX vs plain ZIP

`flutter build windows --release` only ever produces **a folder** (`bookspeaker.exe` +
`flutter_windows.dll` + `data/`). An installer is a wrapper someone has to build around that
folder — which is why the choice matters.

| | **ZIP (portable)** | **EXE installer** (Inno Setup / NSIS) | **MSI** (WiX / Windows Installer) | **MSIX** (`msix` Dart package) |
|---|---|---|---|---|
| What the user gets | a folder to unzip and run | one `Setup.exe`, double-click, wizard | one `.msi`, double-click, wizard | one `.msix` package |
| Shortcuts / uninstaller | none | yes | yes | Start Menu entry only |
| "Apps & features" entry | no | yes | yes | no (removed in Settings → Apps) |
| Install without admin | ✅ | ✅ (per-user) | ✅ (per-user) | ✅ |
| Silent / mass deploy | n/a | `/SILENT` | `/qn` — the enterprise standard (Group Policy, Intune) | Intune only |
| File associations | ❌ | ✅ | ✅ | ✅ (declared in manifest) |
| **Installs at all if unsigned** | ✅ | ✅ (SmartScreen warning) | ✅ (SmartScreen warning) | ❌ **needs a trusted certificate** |
| Where app data lives | normal `%APPDATA%` | normal `%APPDATA%` | normal `%APPDATA%` | **redirected into the package container** |
| Where it's built | anywhere | Windows + Inno Setup | Windows + WiX Toolset v3.14 | Windows + `msix` package |
| Effort for me to author | none | low | medium | low |

### The two things that actually matter for *this* app

**1. MSIX redirects your data folder.** An MSIX package writes `%APPDATA%` into
`…\Packages\<PackageFamilyName>\LocalCache\…` instead of the real `%APPDATA%`. That is
exactly where Bookspeaker keeps `bookspeaker.db` — all your local progress. If the package is
reinstalled, re-signed, or repackaged with a different identity, the app can look up at an
empty folder and appear to have lost everything (Drive still has it, but it's a scare, and
"Locate/Remove" flows get confusing). MSI and EXE keep data in the ordinary location, so a
reinstall or upgrade is invisible to the app.

**2. MSIX cannot be installed unsigned.** You'd need a real code-signing certificate, or a
self-signed one installed into Trusted People **on every PC** first — otherwise Windows
refuses outright. MSI and EXE install unsigned; you only get a one-time SmartScreen
"unknown publisher" prompt.

### What "EXE" can mean (the common confusion)

* The **portable build** — `bookspeaker.exe` inside the folder Flutter produces. No installer
  at all: no shortcut, no uninstaller, and if you move the `.exe` alone it won't run (it needs
  the `data/` folder and DLLs beside it).
* An **EXE installer** — a wizard that unpacks the folder into Program Files/AppData. That's
  what people usually mean by "make me an exe".

### My recommendation

* **Want it to just work on your own PCs, easiest to produce and share?** → **EXE installer
  (Inno Setup)**: one file, per-user, no admin prompt, file associations easy, no WiX
  complexity. Free, and its script is much shorter than WiX authoring.
* **Want the standard Windows package, enterprise-deployable, `/qn` silent install, clean
  uninstall entry?** → **MSI (WiX v3.14)**: the long-established choice, and it keeps app data
  in the normal location. Slightly more authoring work, entirely mine to handle.
* **MSIX** — only worth it if you specifically want Store-style packaging and have (or will
  buy) a signing certificate. Given the data-redirection issue above, I'd avoid it here even
  though the original spec listed the `msix` package.
* **Portable ZIP** is a fine *extra*: I can make the build script emit the MSI/EXE **and** a
  zip of the runnable folder, so you have a no-install version too.

Either installer should also bundle or check the **Microsoft Visual C++ Redistributable**
(Flutter Windows apps need it; the plain zip assumes it's already on the machine).

---

## A. What I need from you: 7 decisions

Answer these and I can write everything; reply "defaults" to take the bracketed choice.

1. **Installer format** — see the comparison above. Choose **MSI**, **EXE installer (Inno
   Setup)**, **MSIX**, or **portable ZIP** (or a combination — MSI + ZIP is a nice pair).
   [default: **MSI**, plus a ZIP of the runnable folder]
2. **Window** — spec says default 420×800, minimum 400×600. Keep? [default: **yes**]
3. **System tray** — minimise to tray and keep playing? Close button = minimise to tray,
   or really quit? [default: **minimise to tray; explicit Quit in the tray menu**]
4. **Mini player** — a small always-on-top "now playing" window? [default: **yes, hidden by
   default, toggled from the tray menu**]
5. **File association** — double-clicking an `.mp3/.m4a/.opus` in Explorer opens Bookspeaker
   and plays it. Registrations are written by the **installer**, so this changes the MSI
   config. [default: **off** — it's the one feature that can't be undone by uninstalling
   cleanly if we get it wrong; say the word and I'll add it]
6. **Install scope** — per-user (no admin prompt, installs to `%LOCALAPPDATA%`) or
   per-machine (`Program Files`, needs admin)? [default: **per-user**]
7. **Code signing** — unsigned (Windows SmartScreen shows "unknown publisher" on first run)
   or signed with your own certificate? [default: **unsigned**; see §D if you want to change it]

## B. What your Windows PC needs (one-time setup)

| Requirement | Notes |
|---|---|
| **Windows 10 64-bit or newer** | Windows 11 fine. ~15 GB free disk. |
| **Flutter SDK (Windows)** | `flutter_windows_3.24.5-stable.zip` — same version as the Android build, so the Dart code behaves identically. Add `flutter\bin` to PATH, run `flutter doctor`. |
| **Visual Studio 2022 Community** | **Must** include the **"Desktop development with C++"** workload plus the *Windows 10/11 SDK*. This is the part people miss — without it `flutter build windows` simply fails. |
| **Git** | For `flutter pub get` on some packages. |
| **WiX Toolset v3.14** (only if you want a `.msi`) | Installer from wixtoolset.org; then `wix` must be on PATH. WiX v4/v5 changed its CLI — v3.14 is the safe choice. |
| **`msix` Dart package** (only if you want `.msix`) | Nothing extra to install; it comes from pubspec. |
| **Your Google account** | Must be listed as a **test user** in the OAuth consent screen (project `bookspeaker-510116`), or the app published — otherwise Windows sign-in is blocked just like on Android. Same account you use on the phone. |

## C. What I'll write (no input needed from you)

* **Desktop sign-in.** `google_sign_in` does **not** work on Windows. I'll implement the
  standard loopback flow using the Desktop client you already sent
  (`credentials/google_desktop_client.json`): open the system browser → you consent →
  redirect to `http://127.0.0.1:<port>` → tokens. The refresh token is stored locally so you
  sign in once. The `drive.appdata` scope is identical to Android, so both platforms share
  the same hidden `Bookspeaker` folder and progress syncs between them.
* **Window behaviour** — min/default sizes, position restore.
* **Tray + mini player** — `tray_manager` / `window_manager`.
* **Installer config** — WiX `.wxs` for the MSI (or `msix_config` in pubspec), with icon,
  publisher name, version, install scope from your answers.
* **An app icon `.ico`** — generated from the existing `assets/icon/bookspeaker_icon.png`.
* **`build_windows.ps1`** — one command that does: `flutter pub get` → `flutter build windows
  --release` → WiX → prints the output path. That's the script you run.

## D. Signing (optional)

An unsigned MSI installs fine but shows "Windows protected your PC" the first time. To avoid
it you need an **Authenticode code-signing certificate**:

* Cheapest that works: a standard OV certificate (~US$200/yr) — SmartScreen reputation still
  takes time to build.
* Immediate trust: EV certificate (hardware token / cloud HSM, more expensive).
* Self-signed (free) — fine for **your own PC only**: you'd trust the certificate manually;
  other machines would still warn.

If you have a `.pfx` + password, don't paste the password in chat — I'll write the build
script to read it from an environment variable instead.

## E. What the first build will realistically look like

Windows-only code cannot be compiled or tested from here — there's no way to run it. I'll
write it carefully and keep the surface small, but expect the first run to hit one or two
compile errors, most likely in:

* the loopback sign-in flow (socket/redirect handling),
* tray/mini-player APIs (they differ subtly by package version).

The loop is: **you run `build_windows.ps1` → paste me the error → I fix it → repeat.** Usually
one or two rounds. Everything I can verify off-Windows — Dart analysis, the shared logic and
the whole test suite — I'll verify here first.

---

### Short answer to "what do I need?"

1. Answer the 7 decisions above (or say "defaults").
2. Have a Windows PC with Flutter + Visual Studio ("Desktop development with C++") installed.
3. Add your Google account as a test user on the consent screen, with the `drive.appdata` scope.
4. Optionally: WiX Toolset v3.14 for a real `.msi`, and a code-signing `.pfx` if you want a
   trusted publisher name.

Then ask me to build, and I'll hand you the source plus the script to run.

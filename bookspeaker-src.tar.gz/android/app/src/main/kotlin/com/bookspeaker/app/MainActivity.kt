package com.bookspeaker.app

import com.ryanheise.audioservice.AudioServiceActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * Hosts the Flutter UI inside audio_service's activity so the media
 * notification, lock-screen and Bluetooth controls keep working while the
 * screen is off.
 *
 * It also exposes one tiny platform method: `moveTaskToBack`. Pressing Back at
 * the root of the app used to finish the activity — Android then showed the
 * (white) launch window while the whole app cold-started again. Backgrounding
 * the task instead keeps playback and the engine alive, so returning is
 * instant and the screen never goes white.
 */
class MainActivity : AudioServiceActivity() {

    private val channelName = "com.bookspeaker.app/platform"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "moveTaskToBack" -> {
                        moveTaskToBack(true)
                        result.success(true)
                    }
                    "sdkInt" -> result.success(android.os.Build.VERSION.SDK_INT)
                    else -> result.notImplemented()
                }
            }
    }
}

// Regression tests for the "wrong cover won't replace" bug and the online
// lookup plumbing.
import 'dart:io';

import 'package:bookspeaker/covers/cover_art_service.dart';
import 'package:bookspeaker/covers/cover_sources/image_validation.dart';
import 'package:bookspeaker/data/db.dart';
import 'package:bookspeaker/library/book_model.dart';
import 'package:flutter_test/flutter_test.dart';

/// A believable JPEG: valid magic bytes + padding so it passes the size check.
List<int> fakeJpeg(int size, int seed) {
  final bytes = List<int>.filled(size, 0);
  bytes[0] = 0xFF;
  bytes[1] = 0xD8;
  bytes[2] = 0xFF;
  for (var i = 3; i < size; i++) {
    bytes[i] = (i * seed) % 256;
  }
  return bytes;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late Directory tmp;
  late Directory cache;
  late BookspeakerDb db;
  late CoverArtService covers;
  late Book book;

  setUp(() {
    tmp = Directory.systemTemp.createTempSync('bookspeaker_cover');
    cache = Directory('${tmp.path}/cover_cache')..createSync(recursive: true);
    db = BookspeakerDb.open('${tmp.path}/bookspeaker.db');
    covers = CoverArtService(db, cache.path);
    book = Book(
      bookId: 'aaaa1111bbbb2222',
      title: 'Wrong Cover',
      author: '',
      filePath: '${tmp.path}/book.mp3',
      folderName: 'books',
      format: AudioFormat.mp3,
      totalDuration: const Duration(hours: 1),
      dateAdded: DateTime.now(),
    );
    db.upsertBook(book);
    File(book.filePath).writeAsBytesSync(List<int>.filled(64, 7));
  });

  tearDown(() {
    db.close();
    if (tmp.existsSync()) tmp.deleteSync(recursive: true);
  });

  test('online candidates must be real images, not placeholders', () {
    // OpenLibrary answers a missing cover with a 43-byte blank GIF.
    expect(CoverImage.isValidCover(List<int>.filled(43, 0)), isFalse);
    expect(CoverImage.isValidCover(fakeJpeg(20000, 3)), isTrue);
    expect(CoverImage.looksLikeImage(fakeJpeg(500, 3)), isTrue);
    expect(CoverImage.looksLikeImage([1, 2, 3, 4]), isFalse);
  });

  test('replacing a cover writes a NEW file, updates the DB and removes the old',
      () async {
    final first = await covers.cacheCover(book, fakeJpeg(20000, 5));
    expect(first, isNotNull);
    expect(db.book(book.bookId)!.coverCachePath, first);
    expect(File(first!).existsSync(), isTrue);

    final second = await covers.cacheCover(book, fakeJpeg(24000, 9));
    expect(second, isNotNull);
    expect(second, isNot(first),
        reason: 'a new filename is what makes the new artwork show up — writing '
            'over the same path left Flutter serving the cached old image');
    expect(db.book(book.bookId)!.coverCachePath, second);
    expect(File(second!).existsSync(), isTrue);
    expect(File(first).existsSync(), isFalse, reason: 'old artwork is pruned');
  });

  test('legacy cached file is still picked up when the DB has no path', () async {
    final legacy = File('${cache.path}/${book.bookId}.jpg')
      ..writeAsBytesSync(fakeJpeg(12000, 3));
    db.setCoverPath(book.bookId, null);

    final resolved = await covers.resolveLocalCover(db.book(book.bookId)!);
    expect(resolved, legacy.path);
  });

  test('manual override wins over the embedded cover on later launches',
      () async {
    final manual = await covers.cacheCover(book, fakeJpeg(30000, 11));
    // resolveLocalCover runs on every book open; it must not replace the
    // user's choice with (or without) the file's embedded artwork.
    final again = await covers.resolveLocalCover(db.book(book.bookId)!);
    expect(again, manual);
  });

  test('non-image payloads are refused instead of cached', () async {
    final bogus = await covers.cacheCover(book, [1, 2, 3, 4, 5]);
    expect(bogus, isNull);
    expect(db.book(book.bookId)!.coverCachePath, isNull);
  });
}

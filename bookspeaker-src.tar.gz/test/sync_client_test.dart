// Regression tests for the "Client is already closed" bug.
//
// The old code shared ONE http.Client for the whole app run and closed it at
// the end of the first Drive session, so every later request failed with
// "HTTP request failed. Client is already closed." — and because unknown
// errors were classified as `offline`, the app blamed the user's connection
// while sitting on 4G.
import 'dart:async';
import 'dart:io';

import 'package:bookspeaker/progress/drive_sync_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;

/// Records whether it was closed, and never touches the network.
class FakeHttpClient extends http.BaseClient {
  bool closed = false;

  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) async {
    if (closed) {
      throw http.ClientException('HTTP request failed. Client is already closed.',
          request.url);
    }
    return http.StreamedResponse(const Stream<List<int>>.empty(), 200);
  }

  @override
  void close() {
    closed = true;
  }
}

void main() {
  test('each session gets its own client, so closing one cannot kill the next',
      () async {
    final created = <FakeHttpClient>[];
    http.Client factory() {
      final c = FakeHttpClient();
      created.add(c);
      return c;
    }

    final first = DriveSyncService.buildSession('token-a', factory);
    final second = DriveSyncService.buildSession('token-b', factory);

    expect(created.length, 2, reason: 'a fresh client per session');
    expect(identical(created[0], created[1]), isFalse);

    // This is what every sync call does in its `finally` block.
    first.client.close();
    expect(created[0].closed, isTrue);

    // The bug: with one shared client, this second client was closed too and
    // the next request died — even though nothing asked for it to be closed.
    expect(created[1].closed, isFalse,
        reason: 'closing session 1 must not close session 2');

    // And the second session really is still usable.
    final response = await second.client
        .send(http.Request('GET', Uri.parse('https://example.test/')));
    expect(response.statusCode, 200);
  });

  test('a closed client error is reported as a bug, not as "offline"',
      () {
    final closedClient = http.ClientException(
      'HTTP request failed. Client is already closed.',
      Uri.parse('https://www.googleapis.com/drive/v3/files'),
    );
    expect(DriveSyncService.classifyError(closedClient), SyncState.error,
        reason: '4G is not the problem when our own client is closed');
  });

  test('real connection failures are still reported as offline', () {
    expect(
      DriveSyncService.classifyError(
        http.ClientException('Connection closed before full header was received'),
      ),
      SyncState.offline,
    );
    expect(
      DriveSyncService.classifyError(const SocketException('Network is unreachable')),
      SyncState.offline,
    );
    expect(
      DriveSyncService.classifyError(TimeoutException('timed out')),
      SyncState.offline,
    );
  });

  test('unknown failures are not disguised as network problems', () {
    expect(DriveSyncService.classifyError(StateError('boom')), SyncState.error);
    expect(DriveSyncService.classifyError(ArgumentError('bad')), SyncState.error);
  });
}

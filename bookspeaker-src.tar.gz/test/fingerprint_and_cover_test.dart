// Verifies the two algorithms that define book identity and cover embedding:
//  1. SHA-256 fingerprinting (stable across rename/move, changes with audio)
//  2. ID3v2 APIC cover embedding (art lands in the tag, audio payload untouched)
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:audio_metadata_reader/audio_metadata_reader.dart';
import 'package:bookspeaker/covers/id3_cover_writer.dart';
import 'package:bookspeaker/library/fingerprint_service.dart';
import 'package:flutter_test/flutter_test.dart';

/// Builds a fake-but-structurally-correct MP3: an ID3v2.3 tag (existing TIT2
/// frame) followed by pseudo-random "audio" bytes.
Uint8List buildFakeMp3({required int audioBytes, required int seed}) {
  final rnd = Random(seed);
  final audio = Uint8List.fromList(
      List<int>.generate(audioBytes, (_) => rnd.nextInt(256)));

  // TIT2 frame: latin1 encoding + text
  const title = 'Original Title';
  final frameBody = <int>[0x00, ...title.codeUnits];
  final frame = <int>[
    ...'TIT2'.codeUnits,
    (frameBody.length >> 24) & 0xFF,
    (frameBody.length >> 16) & 0xFF,
    (frameBody.length >> 8) & 0xFF,
    frameBody.length & 0xFF,
    0x00, 0x00,
    ...frameBody,
  ];
  final size = frame.length;
  return Uint8List.fromList([
    0x49, 0x44, 0x33, 0x03, 0x00, 0x00, // "ID3" v2.3, no flags
    (size >> 21) & 0x7F,
    (size >> 14) & 0x7F,
    (size >> 7) & 0x7F,
    size & 0x7F,
    ...frame,
    ...audio,
  ]);
}

/// Minimal JPEG-ish payload (SOI marker + filler) big enough to be realistic.
Uint8List fakeJpeg(int size) {
  final bytes = Uint8List(size);
  bytes[0] = 0xFF;
  bytes[1] = 0xD8;
  for (var i = 2; i < size; i++) {
    bytes[i] = (i * 7) % 256;
  }
  return bytes;
}

void main() {
  late Directory tmp;
  setUp(() => tmp = Directory.systemTemp.createTempSync('bookspeaker_fp'));
  tearDown(() {
    if (tmp.existsSync()) tmp.deleteSync(recursive: true);
  });

  group('fingerprint', () {
    test('is 16 hex chars and stable across rename + move', () async {
      final a = File('${tmp.path}/gatsby.mp3')
        ..writeAsBytesSync(buildFakeMp3(audioBytes: 300000, seed: 1));
      final idA = await FingerprintService.fingerprint(a.path);

      expect(idA.length, 16);
      expect(RegExp(r'^[0-9a-f]{16}$').hasMatch(idA), isTrue);

      final b = File('${tmp.path}/renamed - chapter one.mp3')
        ..writeAsBytesSync(a.readAsBytesSync());
      expect(await FingerprintService.fingerprint(b.path), idA,
          reason: 'rename must not change the book ID');

      final movedDir = Directory('${tmp.path}/elsewhere')..createSync();
      final c = File('${movedDir.path}/gatsby.mp3')
        ..writeAsBytesSync(a.readAsBytesSync());
      expect(await FingerprintService.fingerprint(c.path), idA,
          reason: 'move must not change the book ID');
    });

    test('changes when the audio actually changes', () async {
      final a = File('${tmp.path}/one.mp3')
        ..writeAsBytesSync(buildFakeMp3(audioBytes: 300000, seed: 1));
      final b = File('${tmp.path}/two.mp3')
        ..writeAsBytesSync(buildFakeMp3(audioBytes: 300000, seed: 2));
      expect(await FingerprintService.fingerprint(a.path),
          isNot(await FingerprintService.fingerprint(b.path)));
    });

    test('ignores tag edits (metadata is skipped before hashing)', () async {
      final a = File('${tmp.path}/tagged.mp3')
        ..writeAsBytesSync(buildFakeMp3(audioBytes: 200000, seed: 7));
      final idBefore = await FingerprintService.fingerprint(a.path);

      // Rewrite the tag with a much larger title, leaving audio identical.
      final jpg = fakeJpeg(40000);
      await Id3CoverWriter.embed(a.path, jpg);
      final idAfter = await FingerprintService.fingerprint(a.path);

      expect(idAfter, idBefore,
          reason: 'adding cover art must keep the same book ID');
    });
  });

  group('cover embedding (ID3 APIC)', () {
    test('writes art into the file and keeps the audio payload intact',
        () async {
      final path = '${tmp.path}/book.mp3';
      final original = buildFakeMp3(audioBytes: 250000, seed: 42);
      File(path).writeAsBytesSync(original);
      final audioBefore = original.sublist(original.length - 250000);

      final jpg = fakeJpeg(60000);
      final ok = await Id3CoverWriter.embed(path, jpg);
      expect(ok, isTrue);

      // 1. The picture is readable back through the metadata parser.
      final meta = readMetadata(File(path), getImage: true);
      expect(meta.pictures, isNotEmpty);
      expect(meta.pictures.first.mimetype, 'image/jpeg');
      expect(meta.pictures.first.bytes.length, jpg.length);
      expect(meta.pictures.first.pictureType, PictureType.coverFront);

      // 2. Existing text frames survive the rewrite.
      expect(meta.title, 'Original Title');

      // 3. No backup files left behind, and the audio bytes are byte-identical.
      expect(File('$path.orig').existsSync(), isFalse);
      expect(File('$path.bsbak').existsSync(), isFalse);
      final after = File(path).readAsBytesSync();
      expect(after.sublist(after.length - 250000), audioBefore);
    });

    test('replacing an existing cover does not stack tags', () async {
      final path = '${tmp.path}/twice.mp3';
      File(path).writeAsBytesSync(buildFakeMp3(audioBytes: 120000, seed: 9));
      await Id3CoverWriter.embed(path, fakeJpeg(30000));
      final firstSize = File(path).lengthSync();
      await Id3CoverWriter.embed(path, fakeJpeg(31000));

      final meta = readMetadata(File(path), getImage: true);
      expect(meta.pictures.length, 1, reason: 'only one front cover at a time');
      final secondSize = File(path).lengthSync();
      expect((secondSize - firstSize).abs() < 5000, isTrue,
          reason: 'tag is rebuilt, not appended twice');
    });
  });
}

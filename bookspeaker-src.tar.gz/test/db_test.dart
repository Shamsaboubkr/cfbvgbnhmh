// Exercises the real SQLite layer against the specified schema.
import 'dart:io';

import 'package:bookspeaker/data/db.dart';
import 'package:bookspeaker/library/book_model.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  late Directory tmp;
  late BookspeakerDb db;

  setUp(() {
    tmp = Directory.systemTemp.createTempSync('bookspeaker_test');
    db = BookspeakerDb.open('${tmp.path}/bookspeaker.db');
  });

  tearDown(() {
    db.close();
    if (tmp.existsSync()) tmp.deleteSync(recursive: true);
  });

  test('schema is created exactly as specified', () {
    final tables = db.allBooks(); // triggers a query; schema must exist
    expect(tables, isEmpty);

    final book = Book(
      bookId: 'a3f9b2c1d4e5f6a7',
      title: 'The Great Gatsby',
      author: 'F. Scott Fitzgerald',
      filePath: '/storage/audiobooks/gatsby.mp3',
      folderName: 'audiobooks',
      format: AudioFormat.mp3,
      totalDuration: const Duration(milliseconds: 33311000),
      dateAdded: DateTime(2024, 1, 15),
    );
    db.upsertBook(book);
    db.ensureProgress(book);

    final stored = db.book('a3f9b2c1d4e5f6a7')!;
    expect(stored.title, 'The Great Gatsby');
    expect(stored.format, AudioFormat.mp3);
    expect(stored.isAvailable, isTrue);
  });

  test('progress round-trips with speed, finish flag and sync status', () {
    final book = Book(
      bookId: 'b4e8c3d2a1b2c3d4',
      title: 'Dune',
      author: 'Frank Herbert',
      filePath: '/books/dune.m4a',
      folderName: 'books',
      format: AudioFormat.m4a,
      totalDuration: const Duration(hours: 21),
      dateAdded: DateTime.now(),
    );
    db.upsertBook(book);

    final pr = db.ensureProgress(book)
      ..position_ms = 9177000
      ..totalDuration_ms = 33311000
      ..percentComplete = 27.4
      ..playbackSpeed = 1.5
      ..lastPlayedDevice = 'Pixel 7'
      ..lastPlayed = DateTime(2024, 1, 15, 14, 32)
      ..syncStatus = SyncStatus.pending;
    db.saveProgress(pr);

    final back = db.progressFor('b4e8c3d2a1b2c3d4')!;
    expect(back.position_ms, 9177000);
    expect(back.playbackSpeed, 1.5);
    expect(back.percentComplete, 27.4);
    expect(back.syncStatus, SyncStatus.pending);
    expect(db.pendingSync().map((p) => p.bookId), contains('b4e8c3d2a1b2c3d4'));

    db.setSyncStatus('b4e8c3d2a1b2c3d4', SyncStatus.synced);
    expect(db.pendingSync(), isEmpty);
  });

  test('bookmarks and device history persist per book', () {
    final book = Book(
      bookId: 'f7a2b1c9d8e7f6a5',
      title: 'Frankenstein',
      author: 'Mary Shelley',
      filePath: '/books/frank.opus',
      folderName: 'books',
      format: AudioFormat.opus,
      totalDuration: const Duration(hours: 8),
      dateAdded: DateTime.now(),
    );
    db.upsertBook(book);
    db.addBookmark(
      book.bookId,
      Bookmark(
        id: 'bm_001',
        position_ms: 5400000,
        label: 'Great quote here',
        created: DateTime(2024, 1, 14, 20, 11),
      ),
    );
    db.addHistoryEntry(
      book.bookId,
      DeviceHistoryEntry(
        deviceName: 'Desktop PC',
        deviceType: 'pc',
        position_ms: 15715000,
        timestamp: DateTime(2024, 1, 15, 9, 15),
      ),
      'h1',
    );

    expect(db.bookmarksFor(book.bookId).single.label, 'Great quote here');
    expect(db.historyFor(book.bookId).single.deviceName, 'Desktop PC');
    final all = db.allBookmarksWithBook();
    expect(all.single.$2, 'f7a2b1c9d8e7f6a5');
    expect(all.single.$3, 'Frankenstein');
  });

  test('watched folders and settings persist', () {
    db.addWatchedFolder('f1', '/storage/audiobooks');
    expect(db.watchedFolders().single.$2, '/storage/audiobooks');

    db.setSetting('skip_forward', '30');
    expect(db.getIntSetting('skip_forward', 15), 30);
    db.setSetting('dynamic_color', 'false');
    expect(db.getBoolSetting('dynamic_color', true), isFalse);

    db.removeWatchedFolder('f1');
    expect(db.watchedFolders(), isEmpty);
  });

  test('cover checks are remembered so launches never re-read every file', () {
    final book = Book(
      bookId: 'dd99887766554433',
      title: 'Slow Launch',
      author: '',
      filePath: '/books/slow.mp3',
      folderName: 'books',
      format: AudioFormat.mp3,
      totalDuration: const Duration(hours: 3),
      dateAdded: DateTime.now(),
    );
    db.upsertBook(book);
    expect(db.book(book.bookId)!.coverChecked, isFalse,
        reason: 'a new book still needs cover resolution');

    db.markCoverChecked(book.bookId);
    expect(db.book(book.bookId)!.coverChecked, isTrue);

    // Re-scanning must not reset the flag.
    db.upsertBook(book.copyWith(title: 'Slow Launch (renamed)'));
    expect(db.book(book.bookId)!.coverChecked, isTrue,
        reason: 'rescanning keeps the checked flag');

    // Clearing the cache deliberately resets it.
    db.resetCoverChecks();
    expect(db.book(book.bookId)!.coverChecked, isFalse);
  });

  test('silence skipping is off by default and persists when enabled', () {
    expect(db.getBoolSetting('skip_silence', false), isFalse,
        reason: 'must never be enabled behind the user\'s back');
    db.setSetting('skip_silence', 'true');
    expect(db.getBoolSetting('skip_silence', false), isTrue);
  });

  test('missing file greys the book out but keeps progress', () {
    final book = Book(
      bookId: 'cc11223344556677',
      title: 'Moved Book',
      author: '',
      filePath: '/books/moved.mp3',
      folderName: 'books',
      format: AudioFormat.mp3,
      totalDuration: const Duration(hours: 2),
      dateAdded: DateTime.now(),
    );
    db.upsertBook(book);
    final pr = db.ensureProgress(book)..position_ms = 600000;
    db.saveProgress(pr);

    db.markUnavailable(book.bookId);
    expect(db.book(book.bookId)!.isAvailable, isFalse);
    expect(db.progressFor(book.bookId)!.position_ms, 600000);

    db.markAvailable(book.bookId, '/books/relocated.mp3');
    expect(db.book(book.bookId)!.filePath, '/books/relocated.mp3');
    expect(db.book(book.bookId)!.isAvailable, isTrue);
  });
}

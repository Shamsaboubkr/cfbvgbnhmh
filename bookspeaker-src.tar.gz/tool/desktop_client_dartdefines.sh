#!/usr/bin/env bash
# Extracts the Desktop-app OAuth client into --dart-define flags for the Windows build.
# Usage:  source <(tool/desktop_client_dartdefines.sh)   # sets  DART_DEFINES
#         flutter build windows --dart-define=... 
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
JSON="$HERE/credentials/google_desktop_client.json"
[ -f "$JSON" ] || { echo "# no $JSON" >&2; exit 1; }
CID=$(python3 -c "import json;print(json.load(open('$JSON'))['installed']['client_id'])")
SEC=$(python3 -c "import json;print(json.load(open('$JSON'))['installed'].get('client_secret',''))")
OUT="--dart-define=BOOKSPEAKER_DESKTOP_CLIENT_ID=$CID"
if [ -n "$SEC" ]; then
  OUT="$OUT --dart-define=BOOKSPEAKER_DESKTOP_CLIENT_SECRET=$SEC"
else
  echo "# note: this client has no client_secret in the JSON; using PKCE loopback flow only" >&2
fi
echo "$OUT"

#!/usr/bin/env python3
"""Tiny download page for the Bookspeaker release APK.

Serves the release/ folder:  /            → landing page with checksum + install steps
                             /<file>.apk  → the APK itself (forced download)

No dependencies beyond the standard library, no host allowlist — safe to run
behind the sandbox preview proxy on 0.0.0.0.
"""
import hashlib
import html
import os
import socket
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

RELEASE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "release")
PORT = int(os.environ.get("PORT", "8080"))
HOST = "0.0.0.0"

PURPLE = "#4A3580"
GOLD = "#C4A35A"


def sha256_of(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def apk_files() -> list[dict]:
    out = []
    for name in sorted(os.listdir(RELEASE_DIR)):
        if not name.lower().endswith(".apk"):
            continue
        path = os.path.join(RELEASE_DIR, name)
        size = os.path.getsize(path)
        out.append(
            {
                "name": name,
                "size": size,
                "size_mb": size / (1024 * 1024),
                "sha256": sha256_of(path),
            }
        )
    return out


def public_base(host: str) -> str:
    """The absolute URL a plain browser tab should use.

    In-app previews render inside a sandboxed iframe without the
    `allow-downloads` permission, so an <a download> there is silently
    ignored — the same link opened as a normal browser tab works.
    """
    if not host or "localhost" in host or host.startswith("127.") or host.startswith("0.0.0.0"):
        return ""
    return f"https://{host}"


def landing_page(host: str) -> bytes:
    files = apk_files()
    base = public_base(host)
    cards = []
    for f in files:
        cards.append(
            f"""
      <div class="card">
        <div class="row">
          <div>
            <h2>{html.escape(f['name'])}</h2>
            <p class="meta">{f['size_mb']:.1f} MB &middot; {f['size']:,} bytes</p>
          </div>
          <a class="btn" href="/{html.escape(f['name'])}" target="_blank" rel="noopener">Download APK</a>
        </div>
        <p class="label">SHA-256</p>
        <code class="hash">{f['sha256']}</code>
      </div>"""
        )
    if not files:
        cards.append('<div class="card"><p>No APK found in release/.</p></div>')

    page = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Bookspeaker — download</title>
<style>
  :root {{ color-scheme: dark; }}
  * {{ box-sizing: border-box; }}
  body {{
    margin: 0; padding: 40px 20px 64px;
    font: 15px/1.55 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    background: radial-gradient(1200px 600px at 15% -10%, #2b1f52 0%, #150f2b 55%, #0d0a1c 100%);
    color: #ece9f6; min-height: 100vh;
  }}
  .wrap {{ max-width: 760px; margin: 0 auto; }}
  header {{ display: flex; align-items: center; gap: 14px; margin-bottom: 6px; }}
  .mark {{
    width: 46px; height: 46px; border-radius: 12px; flex: none;
    background: linear-gradient(145deg, {PURPLE}, #6b52ad);
    display: grid; place-items: center; color: {GOLD};
    font-size: 22px; box-shadow: 0 6px 18px rgba(74,53,128,.55);
  }}
  h1 {{ font-size: 22px; margin: 0; letter-spacing: .2px; }}
  .tagline {{ color: {GOLD}; font-size: 13px; margin: 2px 0 0; }}
  .lede {{ color: #b9b3d0; font-size: 14px; margin: 22px 0 26px; }}
  .card {{
    background: rgba(255,255,255,.045); border: 1px solid rgba(196,163,90,.28);
    border-radius: 16px; padding: 20px 22px; margin-bottom: 18px;
    backdrop-filter: blur(6px);
  }}
  .row {{ display: flex; align-items: flex-start; justify-content: space-between; gap: 18px; flex-wrap: wrap; }}
  h2 {{ font-size: 16px; margin: 0 0 4px; word-break: break-all; }}
  .meta {{ margin: 0; color: #b9b3d0; font-size: 13px; }}
  .btn {{
    display: inline-block; padding: 11px 22px; border-radius: 999px; text-decoration: none;
    background: linear-gradient(145deg, {GOLD}, #a8843f); color: #241a05;
    font-weight: 650; font-size: 14px; white-space: nowrap;
    box-shadow: 0 6px 16px rgba(196,163,90,.3);
  }}
  .btn:hover {{ filter: brightness(1.08); }}
  .label {{ margin: 18px 0 6px; font-size: 11px; letter-spacing: .12em; text-transform: uppercase; color: #8f88ad; }}
  code.hash {{
    display: block; font: 12px/1.5 ui-monospace, SFMono-Regular, Menlo, monospace;
    background: rgba(0,0,0,.35); border-radius: 9px; padding: 10px 12px;
    word-break: break-all; color: #d8d2ec;
  }}
  h3 {{ font-size: 14px; margin: 28px 0 10px; color: {GOLD}; }}
  ol {{ padding-left: 22px; color: #cfc9e2; font-size: 14px; }}
  li {{ margin-bottom: 7px; }}
  .step {{ background: rgba(0,0,0,.35); border-radius: 9px; padding: 10px 12px; margin-top: 8px;
           font: 12px/1.5 ui-monospace, SFMono-Regular, Menlo, monospace; color: #d8d2ec;
           overflow-x: auto; white-space: pre; }}
  .warn {{
    background: rgba(196,163,90,.12); border: 1px solid rgba(196,163,90,.45);
    border-radius: 12px; padding: 14px 16px; font-size: 13.5px; color: #f0e6cd;
    margin-bottom: 10px;
  }}
  .warn code {{ background: rgba(0,0,0,.35); padding: 1px 5px; border-radius: 5px; }}
  .note {{ font-size: 13px; color: #9c95b8; margin-top: 26px; border-top: 1px solid rgba(255,255,255,.08); padding-top: 16px; }}
  a.plain {{ color: {GOLD}; }}
</style>
</head>
<body>
  <div class="wrap">
    <header>
      <div class="mark">&#9835;</div>
      <div>
        <h1>Bookspeaker</h1>
        <p class="tagline">Listen everywhere. Pick up anywhere.</p>
      </div>
    </header>
    <p class="lede">Android build &mdash; Android 9 to Android 15, universal (arm64-v8a, armeabi-v7a,
    x86_64). Signed with the release key, so it installs straight over your current version.</p>

    {'<div class="warn"><strong>Clicking Download does nothing?</strong> '
     'You are viewing this page inside a sandboxed preview pane, which blocks downloads by design. '
     'Copy the link below into a normal browser tab instead &mdash; it is the same file:</div>'
     if base else ''}
    {('<div class="step">'
      + '&#10;'.join(base + '/' + html.escape(f["name"]) for f in files)
      + '</div>') if (base and files) else ''}

    {''.join(cards)}

    <h3>Install on your phone</h3>
    <ol>
      <li>Download the APK above (or copy it across from this page via USB).</li>
      <li>Open it on the phone; allow "install unknown apps" for your file manager when asked.</li>
      <li>It installs over your existing Bookspeaker &mdash; no uninstall needed.</li>
    </ol>
    <div class="step">adb install -r {html.escape(files[0]['name']) if files else 'Bookspeaker.apk'}</div>

    <h3>What is new in this build</h3>
    <ol>
      <li>Drive pushes every 30 s while playing, local saves every 10 s (verified by tests).</li>
      <li>Immediate push on pause, on book switch and on app close &mdash; the last two were broken.</li>
      <li>Sync chip ticks (&ldquo;Synced 12s ago&rdquo;) and holds &ldquo;Syncing&hellip;&rdquo; for 900 ms per push.</li>
      <li>Settings &rarr; Account shows the live cadence counters and a sync activity log.</li>
    </ol>

    <p class="note">Also in <code>release/</code>: <a class="plain" href="/SHA256SUMS.txt">SHA256SUMS.txt</a>.
    Verify a download with <code>sha256sum -c SHA256SUMS.txt</code>.</p>
  </div>
</body>
</html>"""
    return page.encode("utf-8")


class Handler(BaseHTTPRequestHandler):
    server_version = "BookspeakerRelease/1.0"

    def _send(self, code: int, content_type: str, body: bytes, extra: dict | None = None):
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        try:
            if path in ("/", "/index.html"):
                host = self.headers.get("Host", "localhost")
                return self._send(200, "text/html; charset=utf-8", landing_page(host))

            name = os.path.basename(path)
            # Never escape the release folder.
            full = os.path.join(RELEASE_DIR, name)
            if not os.path.abspath(full).startswith(os.path.abspath(RELEASE_DIR)) or not os.path.isfile(full):
                return self._send(404, "text/plain; charset=utf-8", b"Not found\n")

            with open(full, "rb") as fh:
                data = fh.read()

            if name.lower().endswith(".apk"):
                return self._send(
                    200,
                    "application/vnd.android.package-archive",
                    data,
                    {"Content-Disposition": f'attachment; filename="{name}"'},
                )
            return self._send(200, "text/plain; charset=utf-8", data)
        except BrokenPipeError:
            pass
        except Exception as exc:  # keep the server alive whatever happens
            self._send(500, "text/plain; charset=utf-8", f"error: {exc}\n".encode())

    def log_message(self, fmt, *args):
        print(f"[apk-host] {self.address_string()} {fmt % args}", flush=True)


def main():
    if not os.path.isdir(RELEASE_DIR):
        raise SystemExit(f"no release folder at {RELEASE_DIR}")
    srv = ThreadingHTTPServer((HOST, PORT), Handler)
    for f in apk_files():
        print(f"[apk-host] serving {f['name']} ({f['size_mb']:.1f} MB) "
              f"sha256={f['sha256'][:16]}…", flush=True)
    print(f"[apk-host] http://{HOST}:{PORT}/  (hostname {socket.gethostname()})", flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    main()
